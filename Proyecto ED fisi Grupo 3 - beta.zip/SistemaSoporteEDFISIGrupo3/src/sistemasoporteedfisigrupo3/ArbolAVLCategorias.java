package sistemasoporteedfisigrupo3;


// ============================================================================
// ESTRUCTURA DE DATOS: ÁRBOL AVL (Para Categorías Jerárquicas)
// ============================================================================


class ArbolAVLCategorias {
    //Atributos
    private NodoArbolAVL raizArbol;

    //Metodos
    // Obtiene la altura de un nodo controlando nulos
    private int obtenerAltura(NodoArbolAVL nodoActual) {
        //dv
        int alturaCalculada;
        
        //inicio
        if (nodoActual == null) {
            alturaCalculada = 0;
        } else {
            alturaCalculada = nodoActual.alturaNodo;
        }
        return alturaCalculada;
        //fin
    }

    // Calcula el factor de equilibrio para saber si se debe rotar
    private int obtenerFactorEquilibrio(NodoArbolAVL nodoActual) {
        //dv
        int factorCalculado;
        
        //inicio
        if (nodoActual == null) {
            factorCalculado = 0;
        } else {
            factorCalculado = obtenerAltura(nodoActual.nodoIzquierdo) - obtenerAltura(nodoActual.nodoDerecho);
        }
        return factorCalculado;
        //fin
    }

    // Ejecuta una rotación simple hacia la derecha
    private NodoArbolAVL rotarDerecha(NodoArbolAVL nodoY) {
        //dv
        NodoArbolAVL nodoX;
        NodoArbolAVL subArbolT2;

        //inicio
        nodoX = nodoY.nodoIzquierdo;
        subArbolT2 = nodoX.nodoDerecho;

        nodoX.nodoDerecho = nodoY;
        nodoY.nodoIzquierdo = subArbolT2;

        nodoY.alturaNodo = Math.max(obtenerAltura(nodoY.nodoIzquierdo), obtenerAltura(nodoY.nodoDerecho)) + 1;
        nodoX.alturaNodo = Math.max(obtenerAltura(nodoX.nodoIzquierdo), obtenerAltura(nodoX.nodoDerecho)) + 1;

        return nodoX;
        //fin
    }

    // Ejecuta una rotación simple hacia la izquierda
    private NodoArbolAVL rotarIzquierda(NodoArbolAVL nodoX) {
        //dv
        NodoArbolAVL nodoY;
        NodoArbolAVL subArbolT2;

        //inicio
        nodoY = nodoX.nodoDerecho;
        subArbolT2 = nodoY.nodoIzquierdo;

        nodoY.nodoIzquierdo = nodoX;
        nodoX.nodoDerecho = subArbolT2;

        nodoX.alturaNodo = Math.max(obtenerAltura(nodoX.nodoIzquierdo), obtenerAltura(nodoX.nodoDerecho)) + 1;
        nodoY.alturaNodo = Math.max(obtenerAltura(nodoY.nodoIzquierdo), obtenerAltura(nodoY.nodoDerecho)) + 1;

        return nodoY;
        //fin
    }

    // Inserta una nueva categoría en el árbol de forma recursiva y balanceada
    public void insertar(CategoriaProblema nuevaCategoria) {
        //dv
        
        //inicio
        raizArbol = insertarRecursivo(raizArbol, nuevaCategoria);
        //fin
    }

    // Lógica interna recursiva para la inserción y balanceo AVL
    private NodoArbolAVL insertarRecursivo(NodoArbolAVL nodoActual, CategoriaProblema nuevaCategoria) {
        //dv
        int balance;

        //inicio
        if (nodoActual == null) {
            return new NodoArbolAVL(nuevaCategoria);
        }

        if (nuevaCategoria.getCodigoCategoria() < nodoActual.datoCategoria.getCodigoCategoria()) {
            nodoActual.nodoIzquierdo = insertarRecursivo(nodoActual.nodoIzquierdo, nuevaCategoria);
        } else if (nuevaCategoria.getCodigoCategoria() > nodoActual.datoCategoria.getCodigoCategoria()) {
            nodoActual.nodoDerecho = insertarRecursivo(nodoActual.nodoDerecho, nuevaCategoria);
        } else {
            return nodoActual; // Códigos duplicados no se permiten
        }

        nodoActual.alturaNodo = 1 + Math.max(obtenerAltura(nodoActual.nodoIzquierdo), obtenerAltura(nodoActual.nodoDerecho));
        balance = obtenerFactorEquilibrio(nodoActual);

        if (balance > 1 && nuevaCategoria.getCodigoCategoria() < nodoActual.nodoIzquierdo.datoCategoria.getCodigoCategoria()) {
            return rotarDerecha(nodoActual);
        }
        if (balance < -1 && nuevaCategoria.getCodigoCategoria() > nodoActual.nodoDerecho.datoCategoria.getCodigoCategoria()) {
            return rotarIzquierda(nodoActual);
        }
        if (balance > 1 && nuevaCategoria.getCodigoCategoria() > nodoActual.nodoIzquierdo.datoCategoria.getCodigoCategoria()) {
            nodoActual.nodoIzquierdo = rotarIzquierda(nodoActual.nodoIzquierdo);
            return rotarDerecha(nodoActual);
        }
        if (balance < -1 && nuevaCategoria.getCodigoCategoria() < nodoActual.nodoDerecho.datoCategoria.getCodigoCategoria()) {
            nodoActual.nodoDerecho = rotarDerecha(nodoActual.nodoDerecho);
            return rotarIzquierda(nodoActual);
        }

        return nodoActual;
        //fin
    }

    // Retorna una cadena con el árbol visual para la interfaz gráfica
    public String obtenerArbolTextoGUI() {
        //dv
        StringBuilder constructorTexto;
        
        //inicio
        constructorTexto = new StringBuilder();
        constructorTexto.append("--- JERARQUÍA DE CATEGORÍAS TÉCNICAS (ÁRBOL AVL) ---\n\n");
        construirInOrderRecursivo(raizArbol, 0, constructorTexto);
        return constructorTexto.toString();
        //fin
    }

    // Método auxiliar para armar el texto con sangrías
    private void construirInOrderRecursivo(NodoArbolAVL nodoActual, int espacio, StringBuilder constructor) {
        //dv
        
        //inicio
        if (nodoActual != null) {
            espacio += 5;
            construirInOrderRecursivo(nodoActual.nodoDerecho, espacio, constructor);
            constructor.append("\n");
            for (int i = 5; i < espacio; i++) {
                constructor.append(" ");
            }
            constructor.append("[").append(nodoActual.datoCategoria.getCodigoCategoria()).append("] ").append(nodoActual.datoCategoria.getNombreCategoria());
            construirInOrderRecursivo(nodoActual.nodoIzquierdo, espacio, constructor);
        }
        //fin
    }
}
