package sistemasoporteedfisigrupo3;

// ============================================================================
// CONTROLADOR DE NEGOCIO (Parte LOGICA DEL codigo)
// ============================================================================

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

class GestionadorSoporte {
    //Atributos
    private ColaPrioridadTickets colaDePrioridad;
    private ArbolAVLCategorias arbolDeCategorias;
    private GrafoSistemas grafoDeSistemas;
    private List<Ticket> listaRegistroGlobalTodosTickets; // Novedad: Registro de todos los tickets
    private int contadorSecuencialIds;

    //Metodos
    // Constructor del controlador
    public GestionadorSoporte() {
        //dv
        
        //inicio
        this.colaDePrioridad = new ColaPrioridadTickets(100);
        this.arbolDeCategorias = new ArbolAVLCategorias();
        this.grafoDeSistemas = new GrafoSistemas(20);
        this.listaRegistroGlobalTodosTickets = new ArrayList<>();
        this.contadorSecuencialIds = 1;
        //fin
    }

    // Carga automática de datos mock (Pruebas)
    public void cargarDatosInicialesMock() {
        //dv
        Ticket ticketSimuladoSLA;

        //inicio
        // 1. Carga de Categorías
        arbolDeCategorias.insertar(new CategoriaProblema(30, "Software Contabilidad"));
        arbolDeCategorias.insertar(new CategoriaProblema(15, "Hardware Servidores"));
        arbolDeCategorias.insertar(new CategoriaProblema(45, "Redes e Internet"));
        arbolDeCategorias.insertar(new CategoriaProblema(10, "Laptops y Periféricos"));

        // 2. Carga Grafo
        grafoDeSistemas.agregarSistema("Servidor Central");
        grafoDeSistemas.agregarSistema("BD SQL");
        grafoDeSistemas.agregarSistema("Módulo Facturación");
        grafoDeSistemas.agregarSistema("Router Core");

        grafoDeSistemas.agregarDependencia("BD SQL", "Servidor Central");
        grafoDeSistemas.agregarDependencia("Módulo Facturación", "BD SQL");
        grafoDeSistemas.agregarDependencia("Servidor Central", "Router Core");

        // 3. Tickets Iniciales
        Ticket t1 = new Ticket(contadorSecuencialIds++, "Caída BD SQL", 1);
        Ticket t2 = new Ticket(contadorSecuencialIds++, "Impresora falla", 3);
        colaDePrioridad.encolarTicket(t1);
        colaDePrioridad.encolarTicket(t2);
        listaRegistroGlobalTodosTickets.add(t1);
        listaRegistroGlobalTodosTickets.add(t2);

        // 4. Ticket resuelto para SLA
        ticketSimuladoSLA = new Ticket(contadorSecuencialIds++, "Config VPN", 4);
        ticketSimuladoSLA.setEstadoActual("Resuelto");
        ticketSimuladoSLA.setNombreTecnicoAsignado("Carlos Mendoza");
        ticketSimuladoSLA.setFechaHoraCreacion(LocalDateTime.now().minusMinutes(45));
        ticketSimuladoSLA.setFechaHoraResolucion(LocalDateTime.now());
        listaRegistroGlobalTodosTickets.add(ticketSimuladoSLA);
        //fin
    }

    // Flujo gráfico para crear un ticket
    public String crearTicketGUI() {
        //dv
        String descripcionCapturada;
        String prioridadString;
        int prioridadNumerica;
        Ticket nuevoTicket;

        //inicio
        descripcionCapturada = JOptionPane.showInputDialog(null, "Ingrese la descripción del problema técnico:", "Crear Ticket", JOptionPane.QUESTION_MESSAGE);
        if (descripcionCapturada == null || descripcionCapturada.trim().isEmpty()) {
            return "Operación cancelada o descripción vacía.";
        }

        prioridadString = JOptionPane.showInputDialog(null, "Nivel de prioridad:\n1: Crítico\n2: Alto\n3: Medio\n4: Bajo", "Prioridad", JOptionPane.QUESTION_MESSAGE);
        if (prioridadString == null) {
            return "Operación cancelada.";
        }

        try {
            prioridadNumerica = Integer.parseInt(prioridadString);
            if (prioridadNumerica < 1 || prioridadNumerica > 4) {
                return "Error: La prioridad debe ser un número entre 1 y 4.";
            }

            nuevoTicket = new Ticket(contadorSecuencialIds++, descripcionCapturada, prioridadNumerica);
            colaDePrioridad.encolarTicket(nuevoTicket);
            listaRegistroGlobalTodosTickets.add(nuevoTicket); // Guardar en registro global
            
            return "¡Éxito! Ticket #" + nuevoTicket.getIdentificadorTicket() + " creado y encolado según prioridad " + prioridadNumerica + ".";
        } catch (NumberFormatException e) {
            return "Error: Formato de prioridad inválido (Debe ser un número).";
        }
        //fin
    }

    // Extrae y asigna el ticket más prioritario
    public String asignarTecnicoGUI() {
        //dv
        Ticket ticketAtendido;

        //inicio
        ticketAtendido = colaDePrioridad.desencolarMaxPrioridad();

        if (ticketAtendido == null) {
            return "La cola de prioridad está vacía. No hay tickets pendientes.";
        }

        ticketAtendido.setEstadoActual("En Proceso");
        ticketAtendido.setNombreTecnicoAsignado("Técnico de Guardia");

        return "--- TICKET PRIORITARIO ASIGNADO ---\n\n" +
               "ID: " + ticketAtendido.getIdentificadorTicket() + "\n" +
               "Problema: " + ticketAtendido.getDescripcionProblema() + "\n" +
               "Prioridad: " + ticketAtendido.getNivelPrioridad() + "\n" +
               "Asignado a: " + ticketAtendido.getNombreTecnicoAsignado() + "\n" +
               "Nuevo Estado: En Proceso";
        //fin
    }

    // Actualiza el estado de cualquier ticket en la base global
    public String actualizarEstadoGUI() {
        //dv
        String idString;
        int idBuscar;
        String[] opcionesEstado = {"En Proceso", "Resuelto"};
        int eleccion;

        //inicio
        idString = JOptionPane.showInputDialog(null, "Ingrese el ID del ticket a actualizar:", "Actualizar Ticket", JOptionPane.QUESTION_MESSAGE);
        if (idString == null) return "Operación cancelada.";

        try {
            idBuscar = Integer.parseInt(idString);
            for (Ticket ticket : listaRegistroGlobalTodosTickets) {
                if (ticket.getIdentificadorTicket() == idBuscar) {
                    
                    eleccion = JOptionPane.showOptionDialog(null, 
                            "Ticket actual: " + ticket.getDescripcionProblema() + "\nEstado actual: " + ticket.getEstadoActual() + "\n\nSeleccione nuevo estado:", 
                            "Actualizar Estado", JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, opcionesEstado, opcionesEstado[0]);
                    
                    if (eleccion == 0) {
                        ticket.setEstadoActual("En Proceso");
                        ticket.setFechaHoraResolucion(null);
                        return "Ticket #" + idBuscar + " actualizado a 'En Proceso'.";
                    } else if (eleccion == 1) {
                        ticket.setEstadoActual("Resuelto");
                        ticket.setFechaHoraResolucion(LocalDateTime.now());
                        return "Ticket #" + idBuscar + " marcado como 'Resuelto'. Tiempo de resolución registrado.";
                    }
                    return "Operación cancelada.";
                }
            }
            return "No se encontró ningún ticket con el ID " + idBuscar + ".";
        } catch (NumberFormatException e) {
            return "Error: El ID debe ser un número entero válido.";
        }
        //fin
    }

    // NUEVA FUNCIÓN: Muestra todos los tickets registrados en la historia del sistema
    public String mostrarTodosLosTicketsGUI() {
        //dv
        StringBuilder reporte;
        DateTimeFormatter formatoFecha;

        //inicio
        if (listaRegistroGlobalTodosTickets.isEmpty()) {
            return "No hay tickets registrados en el sistema.";
        }

        reporte = new StringBuilder();
        formatoFecha = DateTimeFormatter.ofPattern("HH:mm:ss");
        reporte.append("--- REGISTRO GLOBAL DE TICKETS (TOTAL: ").append(listaRegistroGlobalTodosTickets.size()).append(") ---\n\n");

        for (Ticket t : listaRegistroGlobalTodosTickets) {
            reporte.append("ID: #").append(t.getIdentificadorTicket())
                   .append(" | Prioridad: ").append(t.getNivelPrioridad())
                   .append(" | Estado: [").append(t.getEstadoActual()).append("]\n")
                   .append("  Problema: ").append(t.getDescripcionProblema()).append("\n")
                   .append("  Hora Creación: ").append(t.getFechaHoraCreacion().format(formatoFecha)).append("\n");
            
            if (t.getEstadoActual().equals("Resuelto") && t.getFechaHoraResolucion() != null) {
                reporte.append("  Hora Resolución: ").append(t.getFechaHoraResolucion().format(formatoFecha)).append("\n");
            }
            reporte.append("--------------------------------------------------\n");
        }
        return reporte.toString();
        //fin
    }

    // Calcula el reporte de tiempos de respuesta promedios
    public String generarReporteSLAGUI() {
        //dv
        long minutosTotalesAcumulados;
        int contadorTicketsCerrados;
        long promedioCalculado;
        Duration lapsoDeTiempo;

        //inicio
        minutosTotalesAcumulados = 0;
        contadorTicketsCerrados = 0;

        for (Ticket ticket : listaRegistroGlobalTodosTickets) {
            if (ticket.getEstadoActual().equals("Resuelto") && ticket.getFechaHoraResolucion() != null) {
                lapsoDeTiempo = Duration.between(ticket.getFechaHoraCreacion(), ticket.getFechaHoraResolucion());
                minutosTotalesAcumulados += lapsoDeTiempo.toMinutes();
                contadorTicketsCerrados++;
            }
        }

        if (contadorTicketsCerrados > 0) {
            promedioCalculado = minutosTotalesAcumulados / contadorTicketsCerrados;
            return "--- REPORTE DE NIVELES DE SERVICIO (SLA) ---\n\n" +
                   "Tickets totales en el sistema: " + listaRegistroGlobalTodosTickets.size() + "\n" +
                   "Tickets exitosamente resueltos: " + contadorTicketsCerrados + "\n" +
                   ">> TIEMPO PROMEDIO DE RESOLUCIÓN: " + promedioCalculado + " minutos.";
        } else {
            return "--- REPORTE DE NIVELES DE SERVICIO (SLA) ---\n\n" +
                   "No hay suficientes tickets resueltos para calcular el promedio SLA.";
        }
        //fin
    }

    // Envoltorios para retornar las vistas de Grafos y Árboles
    public String mostrarGrafoGUI() {
        //dv
        //inicio
        return grafoDeSistemas.obtenerGrafoTextoGUI();
        //fin
    }

    public String mostrarArbolAVLGUI() {
        //dv
        //inicio
        return arbolDeCategorias.obtenerArbolTextoGUI();
        //fin
    }
}