package sistemasoporteedfisigrupo3;

// ============================================================================
// CLASE PRINCIPAL Y VENTANA GRÁFICA (parte GRAFICA del codigo)
// ============================================================================


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class SistemaSoporteEDFISIGrupo3 extends JFrame {
    
    //Atributos
    private GestionadorSoporte gestionadorLogica;
    private JTextArea areaPantallaResultados;
    private JButton btnCrearTicket;
    private JButton btnAsignarTecnico;
    private JButton btnActualizarEstado;
    private JButton btnVerTodosTickets;
    private JButton btnReporteSLA;
    private JButton btnVerGrafo;
    private JButton btnVerArbol;
    private JButton btnSalir;

    //Metodos
    // Constructor de la ventana gráfica principal
    public SistemaSoporteEDFISIGrupo3() {
        //dv
        JPanel panelBotonesLateral;
        JScrollPane panelDesplazamientoPantalla;

        //inicio
        gestionadorLogica = new GestionadorSoporte();
        gestionadorLogica.cargarDatosInicialesMock();

        // Configuración básica de la ventana
        setTitle("Sistema de Soporte Técnico - Data Computer");
        setSize(900, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Inicializar componentes visuales
        areaPantallaResultados = new JTextArea();
        areaPantallaResultados.setEditable(false);
        areaPantallaResultados.setFont(new Font("Monospaced", Font.PLAIN, 14));
        areaPantallaResultados.setMargin(new Insets(10, 10, 10, 10));
        
        panelDesplazamientoPantalla = new JScrollPane(areaPantallaResultados);

        panelBotonesLateral = new JPanel();
        panelBotonesLateral.setLayout(new GridLayout(8, 1, 5, 5));
        panelBotonesLateral.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        btnCrearTicket = new JButton("1. Crear nuevo ticket");
        btnAsignarTecnico = new JButton("2. Asignar a técnico (Atender)");
        btnActualizarEstado = new JButton("3. Actualizar estado de ticket");
        btnVerTodosTickets = new JButton("4. Ver TODOS los tickets");
        btnReporteSLA = new JButton("5. Generar reporte SLA");
        btnVerGrafo = new JButton("6. Mapa de Dependencias (Grafo)");
        btnVerArbol = new JButton("7. Categorías (Árbol AVL)");
        btnSalir = new JButton("8. Salir");

        // Agregar botones al panel lateral
        panelBotonesLateral.add(btnCrearTicket);
        panelBotonesLateral.add(btnAsignarTecnico);
        panelBotonesLateral.add(btnActualizarEstado);
        panelBotonesLateral.add(btnVerTodosTickets);
        panelBotonesLateral.add(btnReporteSLA);
        panelBotonesLateral.add(btnVerGrafo);
        panelBotonesLateral.add(btnVerArbol);
        panelBotonesLateral.add(btnSalir);

        // Agregar paneles a la ventana
        add(panelBotonesLateral, BorderLayout.WEST);
        add(panelDesplazamientoPantalla, BorderLayout.CENTER);

        // Configurar las acciones de los botones (Eventos)
        configurarEventosBotones();

        // Mensaje de bienvenida
        areaPantallaResultados.setText("¡Bienvenido al Sistema de Soporte de Data Computer!\nLos datos de prueba (Mocks) se han cargado exitosamente en memoria.\nSeleccione una opción del menú lateral para comenzar.");
        //fin
    }

    // Vincula los clics de los botones con la lógica de negocio
    private void configurarEventosBotones() {
        //dv
        
        //inicio
        btnCrearTicket.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent eventoClic) {
                String resultado = gestionadorLogica.crearTicketGUI();
                areaPantallaResultados.setText(resultado);
            }
        });

        btnAsignarTecnico.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent eventoClic) {
                String resultado = gestionadorLogica.asignarTecnicoGUI();
                areaPantallaResultados.setText(resultado);
            }
        });

        btnActualizarEstado.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent eventoClic) {
                String resultado = gestionadorLogica.actualizarEstadoGUI();
                areaPantallaResultados.setText(resultado);
            }
        });

        btnVerTodosTickets.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent eventoClic) {
                String resultado = gestionadorLogica.mostrarTodosLosTicketsGUI();
                areaPantallaResultados.setText(resultado);
            }
        });

        btnReporteSLA.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent eventoClic) {
                String resultado = gestionadorLogica.generarReporteSLAGUI();
                areaPantallaResultados.setText(resultado);
            }
        });

        btnVerGrafo.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent eventoClic) {
                String resultado = gestionadorLogica.mostrarGrafoGUI();
                areaPantallaResultados.setText(resultado);
            }
        });

        btnVerArbol.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent eventoClic) {
                String resultado = gestionadorLogica.mostrarArbolAVLGUI();
                areaPantallaResultados.setText(resultado);
            }
        });

        btnSalir.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent eventoClic) {
                System.exit(0);
            }
        });
        //fin
    }

    // Método principal que arranca la aplicación gráfica
    public static void main(String[] args) {
        //dv
        
        //inicio
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new SistemaSoporteEDFISIGrupo3().setVisible(true);
            }
        });
        //fin
    }
}