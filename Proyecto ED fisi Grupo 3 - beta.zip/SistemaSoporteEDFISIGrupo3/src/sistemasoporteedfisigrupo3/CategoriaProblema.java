package sistemasoporteedfisigrupo3;

// ============================================================================
// Clase CategoriaProblema
// ============================================================================
// La categoria problema es el tipo de dato que estamos guardando en nuestro
// arbol AVL, guarda la clave y el valor que se van a ordenar en el arbol


class CategoriaProblema {
    //Atributos
    private int codigoCategoria;
    private String nombreCategoria;

    //Metodos
    // Constructor para definir una categoría de soporte
    public CategoriaProblema(int codigo, String nombre) {
        //dv
        
        //inicio
        this.codigoCategoria = codigo;
        this.nombreCategoria = nombre;
        //fin
    }

    public int getCodigoCategoria() { return codigoCategoria; }
    public String getNombreCategoria() { return nombreCategoria; }
}