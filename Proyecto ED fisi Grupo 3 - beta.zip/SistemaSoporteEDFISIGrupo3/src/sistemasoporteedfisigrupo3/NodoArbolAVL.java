package sistemasoporteedfisigrupo3;

// ============================================================================
// ESTRUCTURA DE DATOS: ÁRBOL AVL (Para Categorías Jerárquicas)
// ============================================================================
// Los nodos son de lo que estan compuesto el arbol AVL


class NodoArbolAVL {
    //Atributos
    CategoriaProblema datoCategoria;
    NodoArbolAVL nodoIzquierdo;
    NodoArbolAVL nodoDerecho;
    int alturaNodo;

    //Metodos
    // Constructor del nodo del árbol equilibrado
    public NodoArbolAVL(CategoriaProblema categoria) {
        //dv
        
        //inicio
        this.datoCategoria = categoria;
        this.alturaNodo = 1;
        //fin
    }
}