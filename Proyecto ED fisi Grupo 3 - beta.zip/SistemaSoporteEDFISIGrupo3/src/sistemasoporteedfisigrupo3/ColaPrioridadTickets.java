package sistemasoporteedfisigrupo3;

// ============================================================================
// ESTRUCTURA DE DATOS 2: COLA DE PRIORIDAD (Monticulo)
// ============================================================================
// Arbol Binario Min-Heap que se usa para hallar rapidamente el ticket con la mas alta
// prioridad, es decir el mas antiguo con el menor numero

class ColaPrioridadTickets {
    //Atributos
    private Ticket[] arregloMonticulo;
    private int tamañoActual;
    private int capacidadMaxima;

    //Metodos
    // Constructor de la cola de prioridad acotada por memoria
    public ColaPrioridadTickets(int capacidad) {
        //dv
        
        //inicio
        this.capacidadMaxima = capacidad;
        this.arregloMonticulo = new Ticket[capacidad];
        this.tamañoActual = 0;
        //fin
    }

    // Inserta un ticket y lo reubica según su nivel de prioridad
    public void encolarTicket(Ticket nuevoTicket) {
        //dv
        
        //inicio
        if (tamañoActual >= capacidadMaxima) {
            System.out.println("Error: Memoria de tickets llena.");
            return;
        }
        arregloMonticulo[tamañoActual] = nuevoTicket;
        flotarHaciaArriba(tamañoActual);
        tamañoActual++;
        //fin
    }

    // Desencola el ticket con mayor prioridad (Nivel 1 es el más prioritario)
    public Ticket desencolarMaxPrioridad() {
        //dv
        Ticket ticketPrioritario;

        //inicio
        if (tamañoActual == 0) {
            return null;
        }
        ticketPrioritario = arregloMonticulo[0];
        arregloMonticulo[0] = arregloMonticulo[tamañoActual - 1];
        tamañoActual--;
        hundirHaciaAbajo(0);
        return ticketPrioritario;
        //fin
    }

    // Algoritmo de reordenación hacia arriba para el Heap
    private void flotarHaciaArriba(int indice) {
        //dv
        int indicePadre;
        Ticket temporal;

        //inicio
        indicePadre = (indice - 1) / 2;
        while (indice > 0 && arregloMonticulo[indice].getNivelPrioridad() < arregloMonticulo[indicePadre].getNivelPrioridad()) {
            temporal = arregloMonticulo[indice];
            arregloMonticulo[indice] = arregloMonticulo[indicePadre];
            arregloMonticulo[indicePadre] = temporal;

            indice = indicePadre;
            indicePadre = (indice - 1) / 2;
        }
        //fin
    }

    // Algoritmo de reordenación hacia abajo para el Heap
    private void hundirHaciaAbajo(int indice) {
        //dv
        int indiceHijoIzquierdo;
        int indiceHijoDerecho;
        int indiceMenorPrioridad;
        Ticket temporal;

        //inicio
        while (indice * 2 + 1 < tamañoActual) {
            indiceHijoIzquierdo = indice * 2 + 1;
            indiceHijoDerecho = indice * 2 + 2;
            indiceMenorPrioridad = indiceHijoIzquierdo;

            if (indiceHijoDerecho < tamañoActual && arregloMonticulo[indiceHijoDerecho].getNivelPrioridad() < arregloMonticulo[indiceHijoIzquierdo].getNivelPrioridad()) {
                indiceMenorPrioridad = indiceHijoDerecho;
            }

            if (arregloMonticulo[indice].getNivelPrioridad() <= arregloMonticulo[indiceMenorPrioridad].getNivelPrioridad()) {
                break;
            }

            temporal = arregloMonticulo[indice];
            arregloMonticulo[indice] = arregloMonticulo[indiceMenorPrioridad];
            arregloMonticulo[indiceMenorPrioridad] = temporal;

            indice = indiceMenorPrioridad;
        }
        //fin
    }
}
