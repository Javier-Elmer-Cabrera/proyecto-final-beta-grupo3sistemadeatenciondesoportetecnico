package sistemasoporteedfisigrupo3;

// ============================================================================
// ESTRUCTURA DE DATOS 3: GRAFO DIRIGIDO (Dependencias)
// ============================================================================
// Un grafo que nos muestra como se conecta la infrestructura informatica, es decir
// para a la hora de realizar cualquier mantenimiento ver que partes del sistema de la
// empresa dependen de otras para asi no realizar errores o malograr algo por corregir otra cosa



import java.util.ArrayList;
import java.util.List;

class GrafoSistemas {
    //Atributos
    private List<String> listaNombresSistemas;
    private int[][] matrizAdyacencia;
    private int capacidadMaximaSistemas;

    //Metodos
    // Constructor del grafo basado en una matriz de adyacencia
    public GrafoSistemas(int maxSistemas) {
        //dv
        
        //inicio
        this.capacidadMaximaSistemas = maxSistemas;
        this.listaNombresSistemas = new ArrayList<>();
        this.matrizAdyacencia = new int[maxSistemas][maxSistemas];
        //fin
    }

    // Registra un nuevo nodo (sistema tecnológico)
    public void agregarSistema(String nombreSistema) {
        //dv
        
        //inicio
        if (!listaNombresSistemas.contains(nombreSistema) && listaNombresSistemas.size() < capacidadMaximaSistemas) {
            listaNombresSistemas.add(nombreSistema);
        }
        //fin
    }

    // Registra una arista dirigida (origen -> destino)
    public void agregarDependencia(String sistemaOrigen, String sistemaDestino) {
        //dv
        int indiceOrigen;
        int indiceDestino;

        //inicio
        indiceOrigen = listaNombresSistemas.indexOf(sistemaOrigen);
        indiceDestino = listaNombresSistemas.indexOf(sistemaDestino);

        if (indiceOrigen != -1 && indiceDestino != -1) {
            matrizAdyacencia[indiceOrigen][indiceDestino] = 1;
        }
        //fin
    }

    // Retorna una cadena con el mapa de conexiones para la interfaz gráfica
    public String obtenerGrafoTextoGUI() {
        //dv
        StringBuilder constructorTexto;
        String origen;
        String destino;
        boolean tieneDependencias;

        //inicio
        constructorTexto = new StringBuilder();
        constructorTexto.append("--- MAPA DE DEPENDENCIAS DE INFRAESTRUCTURA (GRAFO) ---\n\n");
        
        for (int i = 0; i < listaNombresSistemas.size(); i++) {
            origen = listaNombresSistemas.get(i);
            constructorTexto.append("Sistema: [").append(origen).append("] depende de -> ");
            tieneDependencias = false;
            
            for (int j = 0; j < listaNombresSistemas.size(); j++) {
                if (matrizAdyacencia[i][j] == 1) {
                    destino = listaNombresSistemas.get(j);
                    constructorTexto.append("[").append(destino).append("] ");
                    tieneDependencias = true;
                }
            }
            if (!tieneDependencias) {
                constructorTexto.append("(Ninguno, es autónomo)");
            }
            constructorTexto.append("\n");
        }
        return constructorTexto.toString();
        //fin
    }
}