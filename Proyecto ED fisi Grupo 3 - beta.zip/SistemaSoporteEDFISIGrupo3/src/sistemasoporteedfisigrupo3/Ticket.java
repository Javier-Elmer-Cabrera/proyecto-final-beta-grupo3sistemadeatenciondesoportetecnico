package sistemasoporteedfisigrupo3;

// ============================================================================
// Clase TICKET
// ============================================================================
//Aqui se da toda la info de el ticket, es decir define que es un ticket y que datos guarda cada ticket

import java.time.LocalDateTime;

class Ticket {
    //Atributos
    private int identificadorTicket;
    private String descripcionProblema;
    private int nivelPrioridad; // 1: Crítico, 2: Alto, 3: Medio, 4: Bajo
    private String estadoActual; // "Abierto", "En Proceso", "Resuelto"
    private LocalDateTime fechaHoraCreacion;
    private LocalDateTime fechaHoraResolucion;
    private String nombreTecnicoAsignado;

    //Metodos
    // Constructor de la clase para inicializar un ticket
    public Ticket(int id, String descripcion, int prioridad) {
        //dv
        
        //inicio
        this.identificadorTicket = id;
        this.descripcionProblema = descripcion;
        this.nivelPrioridad = prioridad;
        this.estadoActual = "Abierto";
        this.fechaHoraCreacion = LocalDateTime.now();
        this.fechaHoraResolucion = null;
        this.nombreTecnicoAsignado = "Ninguno";
        //fin
    }

    public int getIdentificadorTicket() { return identificadorTicket; }
    public String getDescripcionProblema() { return descripcionProblema; }
    public int getNivelPrioridad() { return nivelPrioridad; }
    public String getEstadoActual() { return estadoActual; }
    public void setEstadoActual(String estado) { this.estadoActual = estado; }
    public LocalDateTime getFechaHoraCreacion() { return fechaHoraCreacion; }
    public void setFechaHoraCreacion(LocalDateTime fecha) { this.fechaHoraCreacion = fecha; }
    public LocalDateTime getFechaHoraResolucion() { return fechaHoraResolucion; }
    public void setFechaHoraResolucion(LocalDateTime fecha) { this.fechaHoraResolucion = fecha; }
    public String getNombreTecnicoAsignado() { return nombreTecnicoAsignado; }
    public void setNombreTecnicoAsignado(String tecnico) { this.nombreTecnicoAsignado = tecnico; }
}
