package sistemasoporteedfisigrupo3;

// ============================================================================
// ESTRUCTURA DE DATOS 3: GRAFO DIRIGIDO (Matriz de Adyacencia para Dependencias)
// ============================================================================

import java.util.ArrayList;
import java.util.List;

/**
 * Implementación en memoria RAM de un <b>Grafo Dirigido</b> utilizando una <b>Matriz de Adyacencia</b>.
 * <p>Modela la topología de la infraestructura informática corporativa (servidores, redes, bases de datos).
 * Cada nodo representa un sistema, y una arista dirigida (1 en la matriz) de A hacia B indica que
 * el funcionamiento de A depende de la disponibilidad de B.</p>
 * <p><b>Complejidad Algorítmica:</b></p>
 * <ul>
 *   <li>Consultar si un sistema depende de otro: <b>O(1)</b> por acceso directo a matriz {@code [i][j]}.</li>
 *   <li>Insertar dependencia (arista): <b>O(n)</b> para ubicar índices, luego O(1) en la matriz.</li>
 * </ul>
 */
class GrafoSistemas {
    // Atributos privados (Encapsulación estricta)
    private List<String> listaNombresSistemas;
    private int[][] matrizAdyacencia;
    private int capacidadMaximaSistemas;

    /**
     * Constructor para inicializar el grafo con un límite de sistemas gestionados.
     * @param maxSistemas Cantidad máxima de nodos (vértices) que albergará la matriz cuadrada.
     * @throws IllegalArgumentException si la capacidad máxima es menor o igual a 0.
     */
    public GrafoSistemas(int maxSistemas) {
        //dv
        //inicio
        if (maxSistemas <= 0) {
            throw new IllegalArgumentException("La capacidad del grafo de sistemas debe ser mayor a 0.");
        }
        this.capacidadMaximaSistemas = maxSistemas;
        this.listaNombresSistemas = new ArrayList<>();
        this.matrizAdyacencia = new int[maxSistemas][maxSistemas];
        //fin
    }

    /**
     * Registra un nuevo nodo (sistema informático o servicio corporativo) en el grafo.
     * 
     * @param nombreSistema Nombre identificador único del servicio (ej. "Servidor Base de Datos").
     * @throws IllegalArgumentException si el nombre es nulo o está vacío.
     * @throws IllegalStateException si se intenta exceder la capacidad máxima configurada en la matriz.
     */
    public void agregarSistema(String nombreSistema) {
        //dv
        //inicio
        if (nombreSistema == null || nombreSistema.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre del sistema técnico no puede ser nulo ni vacío.");
        }
        String nombreLimpio = nombreSistema.trim();
        
        if (!listaNombresSistemas.contains(nombreLimpio)) {
            if (listaNombresSistemas.size() >= capacidadMaximaSistemas) {
                throw new IllegalStateException("Desbordamiento en Grafo: Capacidad máxima de sistemas (" + capacidadMaximaSistemas + ") alcanzada.");
            }
            listaNombresSistemas.add(nombreLimpio);
        }
        //fin
    }

    /**
     * Crea una arista dirigida (conexión de dependencia) indicando que un sistema requiere el servicio de otro para funcionar.
     * 
     * @param sistemaOrigen Sistema que necesita del otro (ej. "Portal Web").
     * @param sistemaDestino Sistema del cual se depende (ej. "Base de Datos Core").
     * @throws IllegalArgumentException si alguno de los sistemas especificados no existe previamente en el grafo.
     */
    public void agregarDependencia(String sistemaOrigen, String sistemaDestino) {
        //dv
        int indiceOrigen;
        int indiceDestino;

        //inicio
        if (sistemaOrigen == null || sistemaDestino == null) {
            throw new IllegalArgumentException("Los sistemas origen y destino para la dependencia no pueden ser nulos.");
        }

        indiceOrigen = listaNombresSistemas.indexOf(sistemaOrigen.trim());
        indiceDestino = listaNombresSistemas.indexOf(sistemaDestino.trim());

        if (indiceOrigen == -1 || indiceDestino == -1) {
            throw new IllegalArgumentException("Error de grafo: Al menos uno de los sistemas ('" + sistemaOrigen + "' o '" + sistemaDestino + "') no ha sido registrado como nodo.");
        }

        matrizAdyacencia[indiceOrigen][indiceDestino] = 1;
        //fin
    }

    /**
     * Genera una cadena formateada detallando la topología de dependencias para su visualización en la interfaz gráfica.
     * @return Texto con el desglose de conexiones por cada sistema corporativo.
     */
    public String obtenerGrafoTextoGUI() {
        //dv
        StringBuilder constructorTexto;
        String origen;
        String destino;
        boolean tieneDependencias;

        //inicio
        constructorTexto = new StringBuilder();
        constructorTexto.append("--- MAPA DE DEPENDENCIAS DE INFRAESTRUCTURA ---\n\n");
        
        if (listaNombresSistemas.isEmpty()) {
            constructorTexto.append("No se han registrado sistemas informáticos en la topología de red.\n");
            return constructorTexto.toString();
        }

        for (int i = 0; i < listaNombresSistemas.size(); i++) {
            origen = listaNombresSistemas.get(i);
            constructorTexto.append("Sistema: [").append(origen).append("] depende de -> ");
            tieneDependencias = false;
            
            for (int j = 0; j < listaNombresSistemas.size(); j++) {
                if (matrizAdyacencia[i][j] == 1) {
                    destino = listaNombresSistemas.get(j);
                    constructorTexto.append("[").append(destino).append("] ");
                    tieneDependencias = true;
                }
            }
            if (!tieneDependencias) {
                constructorTexto.append("(Servicio Independiente)");
            }
            constructorTexto.append("\n");
        }
        return constructorTexto.toString();
        //fin
    }

    public int getCantidadSistemas() {
        return listaNombresSistemas.size();
    }

    public List<String> getListaSistemas() {
        return new ArrayList<>(listaNombresSistemas);
    }

    public List<String> getDependenciasDe(String sistema) {
        List<String> dependencias = new ArrayList<>();
        int idx = listaNombresSistemas.indexOf(sistema);
        if (idx != -1) {
            // Recorremos la fila idx en la matriz para detectar aristas salientes (sistemas requeridos en O(V))
            for (int j = 0; j < listaNombresSistemas.size(); j++) {
                if (matrizAdyacencia[idx][j] == 1) {
                    dependencias.add(listaNombresSistemas.get(j));
                }
            }
        }
        return dependencias;
    }

    public List<String> getSistemasAfectadosPor(String sistema) {
        List<String> afectados = new ArrayList<>();
        int idx = listaNombresSistemas.indexOf(sistema);
        if (idx != -1) {
            // Recorremos la columna idx en la matriz para identificar aristas entrantes (sistemas impactados por fallo)
            for (int i = 0; i < listaNombresSistemas.size(); i++) {
                if (matrizAdyacencia[i][idx] == 1) {
                    afectados.add(listaNombresSistemas.get(i));
                }
            }
        }
        return afectados;
    }
}