package sistemasoporteedfisigrupo3;

// ============================================================================
// CONTROLADOR DE NEGOCIO Y FACHADA (Patrón Architectural Facade / Controller)
// ============================================================================

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.tree.DefaultMutableTreeNode;

/**
 * Controlador principal (Arquitectura MVC) que implementa el patrón Fachada
 * (Facade).
 * Desacopla la Vista en Swing de las clases del Modelo (ColaPrioridadTickets,
 * GrafoSistemas y ArbolAVLCategorias).
 * Aplica encapsulación estricta en sus atributos y maneja las excepciones de
 * entrada y desbordamiento.
 */
class GestionadorSoporte {
    // Atributos privados (Encapsulación estricta del modelo de datos)
    private ColaPrioridadTickets colaDePrioridad;
    private ArbolAVLCategorias arbolDeCategorias;
    private GrafoSistemas grafoDeSistemas;
    private List<Ticket> listaRegistroGlobalTodosTickets;
    private int contadorSecuencialIds;

    /**
     * Constructor que inicializa las estructuras en memoria RAM con capacidades
     * predefinidas.
     */
    public GestionadorSoporte() {
        // dv
        // inicio
        this.colaDePrioridad = new ColaPrioridadTickets(100);
        this.arbolDeCategorias = new ArbolAVLCategorias();
        this.grafoDeSistemas = new GrafoSistemas(20);
        this.listaRegistroGlobalTodosTickets = new ArrayList<>();
        this.contadorSecuencialIds = 1;
        // fin
    }

    /**
     * Carga datos iniciales de prueba (Mocks) en las 3 estructuras para facilitar
     * la demostración académica.
     */
    public void cargarDatosInicialesMock() {
        // dv
        Ticket ticketSimuladoSLA;

        // inicio
        try {
            // 1. Carga de Categorías (Árbol AVL auto-balanceado)
            arbolDeCategorias.insertar(new CategoriaProblema(30, "Software Contabilidad"));
            arbolDeCategorias.insertar(new CategoriaProblema(15, "Hardware Servidores"));
            arbolDeCategorias.insertar(new CategoriaProblema(45, "Redes e Internet"));
            arbolDeCategorias.insertar(new CategoriaProblema(10, "Laptops y Periféricos"));

            // 2. Carga de Infraestructura (Grafo de adyacencia)
            grafoDeSistemas.agregarSistema("Servidor Central");
            grafoDeSistemas.agregarSistema("BD SQL");
            grafoDeSistemas.agregarSistema("Módulo Facturación");
            grafoDeSistemas.agregarSistema("Router Core");

            grafoDeSistemas.agregarDependencia("BD SQL", "Servidor Central");
            grafoDeSistemas.agregarDependencia("Módulo Facturación", "BD SQL");
            grafoDeSistemas.agregarDependencia("Servidor Central", "Router Core");

            // 3. Tickets Iniciales (Cola de Prioridad - Min-Heap)
            Ticket t1 = new Ticket(contadorSecuencialIds++, "Caída BD SQL", 1);
            Ticket t2 = new Ticket(contadorSecuencialIds++, "Impresora falla", 3);
            colaDePrioridad.encolarTicket(t1);
            colaDePrioridad.encolarTicket(t2);
            listaRegistroGlobalTodosTickets.add(t1);
            listaRegistroGlobalTodosTickets.add(t2);

            // 4. Ticket resuelto para analítica de SLA
            ticketSimuladoSLA = new Ticket(contadorSecuencialIds++, "Config VPN", 4);
            ticketSimuladoSLA.setEstadoActual("Resuelto");
            ticketSimuladoSLA.setNombreTecnicoAsignado("Carlos Mendoza");
            ticketSimuladoSLA.setFechaHoraCreacion(LocalDateTime.now().minusMinutes(45));
            ticketSimuladoSLA.setFechaHoraResolucion(LocalDateTime.now());
            listaRegistroGlobalTodosTickets.add(ticketSimuladoSLA);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Advertencia durante carga de datos Mock: " + ex.getMessage(),
                    "Advertencia del Sistema", JOptionPane.WARNING_MESSAGE);
        }
        // fin
    }

    /**
     * Flujo interactivo con validación de excepciones para instanciar y encolar una
     * nueva incidencia.
     * 
     * @return Mensaje de respuesta con el resultado de la operación en el Heap.
     */
    public String crearTicketGUI() {
        // dv
        String descripcionCapturada;
        String prioridadString;
        int prioridadNumerica;
        Ticket nuevoTicket;

        // inicio
        descripcionCapturada = JOptionPane.showInputDialog(null, "Descripción de la incidencia:",
                "Registrar Nuevo Ticket", JOptionPane.QUESTION_MESSAGE);
        if (descripcionCapturada == null || descripcionCapturada.trim().isEmpty()) {
            return "Operación cancelada o descripción vacía.";
        }

        prioridadString = JOptionPane.showInputDialog(null,
                "Seleccione la prioridad:\n1: Crítico (SLA 2h)\n2: Alto (SLA 4h)\n3: Medio (SLA 8h)\n4: Bajo (SLA 24h)",
                "Prioridad del Ticket", JOptionPane.QUESTION_MESSAGE);
        if (prioridadString == null) {
            return "Operación cancelada.";
        }

        try {
            prioridadNumerica = Integer.parseInt(prioridadString);
            nuevoTicket = new Ticket(contadorSecuencialIds++, descripcionCapturada, prioridadNumerica);

            colaDePrioridad.encolarTicket(nuevoTicket);
            listaRegistroGlobalTodosTickets.add(nuevoTicket);

            return "¡Éxito! Ticket #" + nuevoTicket.getIdentificadorTicket() + " creado y registrado con prioridad "
                    + prioridadNumerica + ".";
        } catch (NumberFormatException e) {
            return "Error de formato: El nivel de prioridad debe ser un número entero (ej. 1, 2, 3 o 4).";
        } catch (IllegalArgumentException | IllegalStateException ex) {
            return "Error de Validación: " + ex.getMessage();
        }
        // fin
    }

    /**
     * Extrae el ticket de mayor prioridad en tiempo O(log n) desde la raíz del
     * Montículo Binario.
     * 
     * @return Resumen del ticket atendido para renderizado gráfico.
     */
    public String asignarTecnicoGUI() {
        return asignarTecnicoGUI("Técnico de Guardia (Especialista)");
    }

    /**
     * Extrae el ticket de mayor prioridad en tiempo O(log n) desde la raíz del
     * Montículo Binario y le asigna el técnico seleccionado.
     * 
     * @param tecnicoSeleccionado Nombre del técnico seleccionado en la interfaz.
     * @return Resumen del ticket atendido para renderizado gráfico.
     */
    public String asignarTecnicoGUI(String tecnicoSeleccionado) {
        // dv
        Ticket ticketAtendido;

        // inicio
        try {
            ticketAtendido = colaDePrioridad.desencolarMaxPrioridad();

            if (ticketAtendido == null) {
                return "No hay tickets pendientes de atención en este momento.";
            }

            ticketAtendido.setEstadoActual("En Proceso");
            String tecnicoAsignado = (tecnicoSeleccionado != null && !tecnicoSeleccionado.trim().isEmpty())
                    ? tecnicoSeleccionado
                    : "Técnico de Guardia (Especialista)";
            ticketAtendido.setNombreTecnicoAsignado(tecnicoAsignado);

            return "--- ASIGNACIÓN DE TICKET PRIORITARIO ---\n\n" +
                    "ID: #" + ticketAtendido.getIdentificadorTicket() + "\n" +
                    "Problema: " + ticketAtendido.getDescripcionProblema() + "\n" +
                    "Prioridad: " + ticketAtendido.getNivelPrioridad() + "\n" +
                    "Asignado a: " + ticketAtendido.getNombreTecnicoAsignado() + "\n" +
                    "Estado: [En Proceso]";
        } catch (Exception ex) {
            return "Error al asignar técnico: " + ex.getMessage();
        }
        // fin
    }

    /**
     * Permite modificar el ciclo de vida de un ticket en la memoria global,
     * auditando sellos de tiempo.
     * 
     * @return Mensaje de confirmación o error de validación.
     */
    public String actualizarEstadoGUI() {
        // dv
        String idString;
        int idBuscar;
        String[] opcionesEstado = { "En Proceso", "Resuelto" };
        int eleccion;

        // inicio
        idString = JOptionPane.showInputDialog(null, "ID numérico del ticket a actualizar:",
                "Actualizar Estado", JOptionPane.QUESTION_MESSAGE);
        if (idString == null)
            return "Operación cancelada.";

        try {
            idBuscar = Integer.parseInt(idString);
            for (Ticket ticket : listaRegistroGlobalTodosTickets) {
                if (ticket.getIdentificadorTicket() == idBuscar) {

                    eleccion = JOptionPane.showOptionDialog(null,
                            "Incidencia: " + ticket.getDescripcionProblema() + "\nEstado actual: ["
                                    + ticket.getEstadoActual() + "]\n\nSeleccione el nuevo estado:",
                            "Actualizar Estado de Incidencia", JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE,
                            null,
                            opcionesEstado, opcionesEstado[0]);

                    if (eleccion == 0) {
                        ticket.setEstadoActual("En Proceso");
                        ticket.setFechaHoraResolucion(null);
                        return "Ticket #" + idBuscar + " actualizado a estado 'En Proceso'.";
                    } else if (eleccion == 1) {
                        ticket.setEstadoActual("Resuelto");
                        ticket.setFechaHoraResolucion(LocalDateTime.now());
                        return "Ticket #" + idBuscar
                                + " marcado como 'Resuelto'. Fecha de cierre registrada exitosamente.";
                    }
                    return "Operación cancelada por el usuario.";
                }
            }
            return "No se encontró ningún ticket registrado con el ID #" + idBuscar + ".";
        } catch (NumberFormatException e) {
            return "Error de formato: El ID del ticket debe ser un número entero válido.";
        } catch (IllegalArgumentException ex) {
            return "Error al actualizar estado: " + ex.getMessage();
        }
        // fin
    }

    /**
     * Muestra el inventario total y el historial completo de incidencias creadas en
     * el sistema.
     */
    public String mostrarTodosLosTicketsGUI() {
        // dv
        StringBuilder reporte;
        DateTimeFormatter formatoFecha;

        // inicio
        if (listaRegistroGlobalTodosTickets.isEmpty()) {
            return "No hay tickets registrados actualmente en el sistema.";
        }

        reporte = new StringBuilder();
        formatoFecha = DateTimeFormatter.ofPattern("HH:mm:ss");
        reporte.append("--- REGISTRO GENERAL DE INCIDENCIAS (TOTAL: ").append(listaRegistroGlobalTodosTickets.size())
                .append(") ---\n\n");

        for (Ticket t : listaRegistroGlobalTodosTickets) {
            reporte.append("ID: #").append(t.getIdentificadorTicket())
                    .append(" | Prioridad: ").append(t.getNivelPrioridad())
                    .append(" | Estado: [").append(t.getEstadoActual()).append("]\n")
                    .append("  Problema: ").append(t.getDescripcionProblema()).append("\n")
                    .append("  Hora Creación: ").append(t.getFechaHoraCreacion().format(formatoFecha)).append("\n");

            if (t.getEstadoActual().equals("Resuelto") && t.getFechaHoraResolucion() != null) {
                reporte.append("  Hora Resolución: ").append(t.getFechaHoraResolucion().format(formatoFecha))
                        .append("\n");
            }
            reporte.append("--------------------------------------------------\n");
        }
        return reporte.toString();
        // fin
    }

    /**
     * Calcula la analítica de tiempos de respuesta promedios según la duración
     * entre creación y resolución.
     */
    public String generarReporteSLAGUI() {
        // dv
        long minutosTotalesAcumulados;
        int contadorTicketsCerrados;
        long promedioCalculado;
        Duration lapsoDeTiempo;

        // inicio
        minutosTotalesAcumulados = 0;
        contadorTicketsCerrados = 0;

        for (Ticket ticket : listaRegistroGlobalTodosTickets) {
            if (ticket.getEstadoActual().equals("Resuelto") && ticket.getFechaHoraResolucion() != null) {
                lapsoDeTiempo = Duration.between(ticket.getFechaHoraCreacion(), ticket.getFechaHoraResolucion());
                minutosTotalesAcumulados += lapsoDeTiempo.toMinutes();
                contadorTicketsCerrados++;
            }
        }

        if (contadorTicketsCerrados > 0) {
            promedioCalculado = minutosTotalesAcumulados / contadorTicketsCerrados;
            return "--- REPORTE DE NIVELES DE SERVICIO (SLA) ---\n\n" +
                    "Tickets totales en el sistema: " + listaRegistroGlobalTodosTickets.size() + "\n" +
                    "Tickets exitosamente resueltos: " + contadorTicketsCerrados + "\n" +
                    ">> TIEMPO PROMEDIO DE RESOLUCIÓN: " + promedioCalculado + " minutos.";
        } else {
            return "--- REPORTE DE NIVELES DE SERVICIO (SLA) ---\n\n" +
                    "No hay suficientes tickets en estado 'Resuelto' para calcular el tiempo promedio SLA.";
        }
        // fin
    }

    /**
     * Envoltorio (Wrapper) para consultar la topología de red en el Grafo Dirigido.
     */
    public String mostrarGrafoGUI() {
        // dv
        // inicio
        return grafoDeSistemas.obtenerGrafoTextoGUI();
        // fin
    }

    /**
     * Envoltorio (Wrapper) para consultar la jerarquía de especialidades en el
     * Árbol AVL.
     */
    public String mostrarArbolAVLGUI() {
        // dv
        // inicio
        return arbolDeCategorias.obtenerArbolTextoGUI();
        // fin
    }

    public boolean hayTicketsPendientes() {
        return !colaDePrioridad.estaVacia();
    }

    public String[] getTecnicosDisponibles() {
        return new String[] {
                "Técnico 1 - Redes e Infraestructura",
                "Técnico 2 - Base de Datos y Servidores",
                "Técnico 3 - Hardware y Periféricos",
                "Técnico 4 - Software y ERP"
        };
    }

    /**
     * Retorna los datos estructurados del Grafo de Sistemas para poblar el JTable
     * del Mapa de Infraestructura.
     * Columnas: [Sistema / Servicio, Requiere para operar (Depende de), Afecta en
     * cascada a]
     */
    public Object[][] obtenerDatosTablaGrafo() {
        List<String> sistemas = grafoDeSistemas.getListaSistemas();
        Object[][] datos = new Object[sistemas.size()][3];
        for (int i = 0; i < sistemas.size(); i++) {
            String sis = sistemas.get(i);
            List<String> dependeDe = grafoDeSistemas.getDependenciasDe(sis);
            List<String> afectaA = grafoDeSistemas.getSistemasAfectadosPor(sis);

            datos[i][0] = sis;
            datos[i][1] = dependeDe.isEmpty() ? "(Servicio Independiente)" : String.join(", ", dependeDe);
            datos[i][2] = afectaA.isEmpty() ? "(Ninguno)" : String.join(", ", afectaA);
        }
        return datos;
    }

    /**
     * Retorna el modelo jerárquico DefaultMutableTreeNode para alimentar el
     * componente JTree del catálogo de categorías.
     */
    public DefaultMutableTreeNode obtenerModeloArbolJTree() {
        DefaultMutableTreeNode raizJTree = new DefaultMutableTreeNode("Catálogo Jerárquico de Categorías (Árbol AVL)");
        NodoArbolAVL raizAVL = arbolDeCategorias.getRaizArbol();
        if (raizAVL != null) {
            DefaultMutableTreeNode nodoRaiz = construirNodoJTreeRecursivo(raizAVL, "Raíz AVL");
            raizJTree.add(nodoRaiz);
        } else {
            raizJTree.add(new DefaultMutableTreeNode("Catálogo Vacío"));
        }
        return raizJTree;
    }

    private DefaultMutableTreeNode construirNodoJTreeRecursivo(NodoArbolAVL nodoAVL, String relacion) {
        if (nodoAVL == null)
            return null;

        DefaultMutableTreeNode nodoJTree = new DefaultMutableTreeNode(
                "[" + relacion + "] Cód. " + nodoAVL.datoCategoria.getCodigoCategoria() + " — "
                        + nodoAVL.datoCategoria.getNombreCategoria());

        if (nodoAVL.nodoIzquierdo != null) {
            nodoJTree.add(construirNodoJTreeRecursivo(nodoAVL.nodoIzquierdo, "Subcat. Izquierda"));
        }
        if (nodoAVL.nodoDerecho != null) {
            nodoJTree.add(construirNodoJTreeRecursivo(nodoAVL.nodoDerecho, "Subcat. Derecha"));
        }
        return nodoJTree;
    }
}