package sistemasoporteedfisigrupo3;

// ============================================================================
// ESTRUCTURA DE DATOS 2: COLA DE PRIORIDAD (Montículo Binario / Min-Heap)
// ============================================================================

/**
 * Implementación en memoria RAM de una <b>Cola de Prioridad</b> basada en un <b>Montículo Binario de Mínimos (Min-Heap)</b>.
 * <p>En un Help Desk corporativo, las incidencias no se atienden por orden de llegada (FIFO), sino por su gravedad crítica.
 * Esta estructura garantiza que el ticket con menor número de prioridad (ej. Prioridad 1 - Crítico) se ubique siempre
 * en la raíz del árbol binario completo (índice 0 del arreglo), permitiendo su extracción inmediata.</p>
 * <p><b>Complejidad Algorítmica:</b></p>
 * <ul>
 *   <li>Consultar máximo prioritario (Raíz): <b>O(1)</b>.</li>
 *   <li>Encolar nuevo ticket (Sift-Up / Flotación): <b>O(log n)</b>.</li>
 *   <li>Desencolar atención (Sift-Down / Hundimiento): <b>O(log n)</b>.</li>
 * </ul>
 */
class ColaPrioridadTickets {
    // Atributos privados para garantizar encapsulación y protección del arreglo interno
    private Ticket[] arregloMonticulo;
    private int tamañoActual;
    private int capacidadMaxima;

    /**
     * Constructor para inicializar el montículo binario con una capacidad de memoria acotada.
     * @param capacidad Número máximo de incidencias que puede alojar la cola simultáneamente.
     * @throws IllegalArgumentException si la capacidad especificada es menor o igual a cero.
     */
    public ColaPrioridadTickets(int capacidad) {
        //dv
        //inicio
        if (capacidad <= 0) {
            throw new IllegalArgumentException("La capacidad máxima de la cola de prioridad debe ser un entero positivo mayor a 0.");
        }
        this.capacidadMaxima = capacidad;
        this.arregloMonticulo = new Ticket[capacidad];
        this.tamañoActual = 0;
        //fin
    }

    /**
     * Inserta un nuevo ticket en la última posición del arreglo y lo reubica hacia la raíz (flotación)
     * según su nivel de prioridad para restaurar la propiedad del Min-Heap.
     * 
     * @param nuevoTicket Objeto de tipo {@link Ticket} a encolar.
     * @throws IllegalArgumentException si el ticket proporcionado es nulo.
     * @throws IllegalStateException si la cola de prioridad ha alcanzado su capacidad máxima de memoria.
     */
    public void encolarTicket(Ticket nuevoTicket) {
        //dv
        //inicio
        if (nuevoTicket == null) {
            throw new IllegalArgumentException("No se puede encolar una incidencia nula en el montículo.");
        }
        if (tamañoActual >= capacidadMaxima) {
            throw new IllegalStateException("Desbordamiento de memoria: El montículo de prioridad ha alcanzado su capacidad máxima (" + capacidadMaxima + " tickets).");
        }
        
        // Colocamos el ticket al final del arreglo y lo subimos por el árbol binario hasta cumplir la propiedad Min-Heap
        arregloMonticulo[tamañoActual] = nuevoTicket;
        flotarHaciaArriba(tamañoActual);
        tamañoActual++;
        //fin
    }

    /**
     * Extrae y retorna el ticket de máxima prioridad ubicado en la raíz del montículo (índice 0).
     * Reemplaza la raíz con el último elemento y aplica el algoritmo de hundimiento para restaurar el equilibrio.
     * 
     * @return El objeto {@link Ticket} más urgente, o {@code null} si la cola está vacía.
     */
    public Ticket desencolarMaxPrioridad() {
        //dv
        Ticket ticketPrioritario;

        //inicio
        if (tamañoActual == 0) {
            return null; // Cola vacía, controlado de forma segura para la interfaz
        }
        
        // La raíz (índice 0) siempre garantiza el ticket con menor número de prioridad en O(1)
        ticketPrioritario = arregloMonticulo[0];
        
        // Reemplazamos la raíz con la última hoja y bajamos el elemento en O(log n) para mantener el orden
        arregloMonticulo[0] = arregloMonticulo[tamañoActual - 1];
        arregloMonticulo[tamañoActual - 1] = null; // Ayuda al Recolector de Basura (Garbage Collector)
        tamañoActual--;
        
        if (tamañoActual > 0) {
            hundirHaciaAbajo(0);
        }
        return ticketPrioritario;
        //fin
    }

    /**
     * Algoritmo privado de reordenación ascendente (Sift-Up / Flotación).
     * Compara el nodo recién insertado con su padre y los intercambia si el hijo tiene mayor prioridad (menor valor numérico).
     */
    private void flotarHaciaArriba(int indice) {
        //dv
        int indicePadre;
        Ticket temporal;

        //inicio
        indicePadre = (indice - 1) / 2;
        // Subimos mientras el hijo sea más prioritario (numéricamente menor) que su padre en el montículo
        while (indice > 0 && arregloMonticulo[indice].compareTo(arregloMonticulo[indicePadre]) < 0) {
            temporal = arregloMonticulo[indice];
            arregloMonticulo[indice] = arregloMonticulo[indicePadre];
            arregloMonticulo[indicePadre] = temporal;

            indice = indicePadre;
            indicePadre = (indice - 1) / 2;
        }
        //fin
    }

    /**
     * Algoritmo privado de reordenación descendente (Sift-Down / Hundimiento).
     * Compara la nueva raíz con sus hijos izquierdo y derecho, intercambiándola con el de mayor prioridad hasta estabilizar el Heap.
     */
    private void hundirHaciaAbajo(int indice) {
        //dv
        int indiceHijoIzquierdo;
        int indiceHijoDerecho;
        int indiceMenorPrioridad;
        Ticket temporal;

        //inicio
        while (indice * 2 + 1 < tamañoActual) {
            indiceHijoIzquierdo = indice * 2 + 1;
            indiceHijoDerecho = indice * 2 + 2;
            indiceMenorPrioridad = indiceHijoIzquierdo;

            if (indiceHijoDerecho < tamañoActual && arregloMonticulo[indiceHijoDerecho].compareTo(arregloMonticulo[indiceHijoIzquierdo]) < 0) {
                indiceMenorPrioridad = indiceHijoDerecho;
            }

            if (arregloMonticulo[indice].compareTo(arregloMonticulo[indiceMenorPrioridad]) <= 0) {
                break;
            }

            temporal = arregloMonticulo[indice];
            arregloMonticulo[indice] = arregloMonticulo[indiceMenorPrioridad];
            arregloMonticulo[indiceMenorPrioridad] = temporal;

            indice = indiceMenorPrioridad;
        }
        //fin
    }

    public int getTamañoActual() {
        return tamañoActual;
    }

    public boolean estaVacia() {
        return tamañoActual == 0;
    }
}

