package sistemasoporteedfisigrupo3;

// ============================================================================
// CLASE PRINCIPAL Y VENTANA GRÁFICA DIDÁCTICA (Parte GRÁFICA del código)
// ============================================================================

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.tree.DefaultMutableTreeNode;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * Ventana gráfica principal del Sistema de Soporte Técnico (EDFISI - Grupo 3).
 * Diseño visual y didáctico para ilustrar el funcionamiento de estructuras en
 * memoria:
 * - Cola de Prioridad (Montículo Binario / Heap)
 * - Grafo de Dependencias (Listas de Adyacencia / BFS)
 * - Árbol AVL de Categorías (Árbol de Búsqueda Auto-Balanceado)
 */
public class SistemaSoporteEDFISIGrupo3 extends JFrame {

    // Atributos de Lógica y Vista
    private GestionadorSoporte gestionadorLogica;
    private JEditorPane areaPantallaResultados; // Mejorado a JEditorPane para renderizado HTML didáctico
    private JPanel panelCentralContainer;
    private CardLayout cardLayoutCentral;
    private JPanel panelAsignacionTecnico;
    private JPanel panelMapaInfraestructura;
    private JPanel panelCatalogoCategorias;

    // Botones del menú de navegación
    private JButton btnCrearTicket;
    private JButton btnAsignarTecnico;
    private JButton btnActualizarEstado;
    private JButton btnVerTodosTickets;
    private JButton btnReporteSLA;
    private JButton btnVerGrafo;
    private JButton btnVerArbol;
    private JButton btnSalir;

    // Paleta de Colores Moderna (Tema Oscuro para lateral, Claro y Elegante para
    // contenido)
    private final Color COLOR_NAVY_HEADER = new Color(15, 23, 42); // Slate 900
    private final Color COLOR_SIDEBAR_BG = new Color(30, 41, 59); // Slate 800
    private final Color COLOR_SIDEBAR_HOVER = new Color(51, 65, 85); // Slate 700
    private final Color COLOR_ACCENT_BLUE = new Color(59, 130, 246); // Blue 500
    private final Color COLOR_BG_LIGHT = new Color(248, 250, 252);// Slate 50

    // Constructor de la ventana gráfica principal
    public SistemaSoporteEDFISIGrupo3() {
        // dv
        JPanel panelBotonesLateral;
        JScrollPane panelDesplazamientoPantalla;
        JPanel panelHeader;
        JPanel panelStatus;

        // inicio
        gestionadorLogica = new GestionadorSoporte();
        gestionadorLogica.cargarDatosInicialesMock();

        // 1. Configuración básica de la ventana principal
        setTitle("Data Computer — Sistema de Gestión de Soporte Técnico");
        setSize(1080, 720);
        setMinimumSize(new Dimension(900, 550));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // 2. Panel Superior (Header Banner con título y subtítulo)
        panelHeader = crearPanelHeader();
        add(panelHeader, BorderLayout.NORTH);

        // 3. Panel Central con CardLayout (para alternar entre Resultados HTML y Panel de Asignación)
        cardLayoutCentral = new CardLayout();
        panelCentralContainer = new JPanel(cardLayoutCentral);

        areaPantallaResultados = new JEditorPane();
        areaPantallaResultados.setContentType("text/html");
        areaPantallaResultados.setEditable(false);
        areaPantallaResultados.setBackground(COLOR_BG_LIGHT);

        panelDesplazamientoPantalla = new JScrollPane(areaPantallaResultados);
        panelDesplazamientoPantalla.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        panelDesplazamientoPantalla.getViewport().setBackground(COLOR_BG_LIGHT);

        panelAsignacionTecnico = new JPanel(new BorderLayout());
        panelAsignacionTecnico.setBackground(COLOR_BG_LIGHT);

        panelMapaInfraestructura = new JPanel(new BorderLayout());
        panelMapaInfraestructura.setBackground(COLOR_BG_LIGHT);

        panelCatalogoCategorias = new JPanel(new BorderLayout());
        panelCatalogoCategorias.setBackground(COLOR_BG_LIGHT);

        panelCentralContainer.add(panelDesplazamientoPantalla, "HTML_VIEW");
        panelCentralContainer.add(panelAsignacionTecnico, "ASIGNACION_VIEW");
        panelCentralContainer.add(panelMapaInfraestructura, "GRAFO_VIEW");
        panelCentralContainer.add(panelCatalogoCategorias, "ARBOL_VIEW");

        add(panelCentralContainer, BorderLayout.CENTER);

        // 4. Panel Lateral de Navegación (Sidebar)
        panelBotonesLateral = crearPanelSidebar();
        add(panelBotonesLateral, BorderLayout.WEST);

        // 5. Panel Inferior de Estado (Status Bar)
        panelStatus = crearPanelStatus();
        add(panelStatus, BorderLayout.SOUTH);

        // 6. Configurar eventos de los botones y mostrar pantalla de bienvenida
        configurarEventosBotones();
        mostrarPantallaBienvenida();
        // fin
    }

    /**
     * Crea el banner superior de la aplicación con estilo corporativo y título claro.
     */
    private JPanel crearPanelHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(COLOR_NAVY_HEADER);
        header.setBorder(BorderFactory.createEmptyBorder(18, 25, 18, 25));

        JLabel lblTitulo = new JLabel("DATA COMPUTER | Mesa de Ayuda Corporativa");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblTitulo.setForeground(Color.WHITE);

        JLabel lblSubtitulo = new JLabel("Consola de Operaciones de Soporte y Gestión de Incidencias");
        lblSubtitulo.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lblSubtitulo.setForeground(new Color(148, 163, 184)); // Slate 400

        header.add(lblTitulo, BorderLayout.NORTH);
        header.add(lblSubtitulo, BorderLayout.SOUTH);
        return header;
    }

    /**
     * Crea el panel lateral (Sidebar) con botones estilizados de navegación.
     */
    private JPanel crearPanelSidebar() {
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(COLOR_SIDEBAR_BG);
        sidebar.setBorder(BorderFactory.createEmptyBorder(15, 12, 15, 12));
        sidebar.setPreferredSize(new Dimension(260, 0));

        // Botones operativos de navegación
        btnCrearTicket = crearBotonMenu("Crear Ticket", "Registrar una nueva incidencia en el sistema");
        btnAsignarTecnico = crearBotonMenu("Asignar Técnico", "Atender el ticket de mayor prioridad pendiente");
        btnActualizarEstado = crearBotonMenu("Actualizar Estado", "Modificar el estado de un ticket existente");
        btnVerTodosTickets = crearBotonMenu("Historial de Tickets", "Consultar el listado general de incidencias");
        btnReporteSLA = crearBotonMenu("Reporte SLA", "Indicadores de nivel de servicio y tiempos de respuesta");
        btnVerGrafo = crearBotonMenu("Mapa de Infraestructura", "Consultar dependencias entre sistemas informáticos");
        btnVerArbol = crearBotonMenu("Catálogo de Categorías", "Ver jerarquía de categorías técnicas");
        btnSalir = crearBotonMenu("Salir", "Cerrar la sesión operativa");

        // Sección: GESTIÓN DE INCIDENCIAS
        sidebar.add(crearEtiquetaSeccion("GESTIÓN DE INCIDENCIAS"));
        sidebar.add(btnCrearTicket);
        sidebar.add(Box.createRigidArea(new Dimension(0, 6)));
        sidebar.add(btnAsignarTecnico);
        sidebar.add(Box.createRigidArea(new Dimension(0, 6)));
        sidebar.add(btnActualizarEstado);
        sidebar.add(Box.createRigidArea(new Dimension(0, 6)));
        sidebar.add(btnVerTodosTickets);
        sidebar.add(Box.createRigidArea(new Dimension(0, 18)));

        // Sección: INFRAESTRUCTURA Y REPORTES
        sidebar.add(crearEtiquetaSeccion("INFRAESTRUCTURA Y REPORTES"));
        sidebar.add(btnReporteSLA);
        sidebar.add(Box.createRigidArea(new Dimension(0, 6)));
        sidebar.add(btnVerGrafo);
        sidebar.add(Box.createRigidArea(new Dimension(0, 6)));
        sidebar.add(btnVerArbol);
        sidebar.add(Box.createVerticalGlue());

        // Sección: SISTEMA
        sidebar.add(crearEtiquetaSeccion("SISTEMA"));
        sidebar.add(btnSalir);

        return sidebar;
    }

    /**
     * Crea la barra de estado inferior para mostrar información de ejecución en tiempo real.
     */
    private JPanel crearPanelStatus() {
        JPanel status = new JPanel(new BorderLayout());
        status.setBackground(new Color(241, 245, 249)); // Slate 100
        status.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, new Color(203, 213, 225)));
        status.setPreferredSize(new Dimension(0, 32));

        JLabel lblEstado = new JLabel("  Estado: Sistema Operativo | Conexión activa");
        lblEstado.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblEstado.setForeground(new Color(51, 65, 85));

        JLabel lblCreditos = new JLabel("Mesa de Ayuda  ");
        lblCreditos.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblCreditos.setForeground(new Color(71, 85, 105));

        status.add(lblEstado, BorderLayout.WEST);
        status.add(lblCreditos, BorderLayout.EAST);
        return status;
    }

    /**
     * Método auxiliar para generar etiquetas de categoría en la barra lateral.
     */
    private JLabel crearEtiquetaSeccion(String texto) {
        JLabel etiqueta = new JLabel(texto);
        etiqueta.setFont(new Font("Segoe UI", Font.BOLD, 11));
        etiqueta.setForeground(new Color(148, 163, 184)); // Slate 400
        etiqueta.setBorder(BorderFactory.createEmptyBorder(6, 8, 8, 0));
        etiqueta.setAlignmentX(Component.LEFT_ALIGNMENT);
        return etiqueta;
    }

    /**
     * Método auxiliar que crea un botón de navegación con diseño corporativo y
     * efectos de hover.
     */
    private JButton crearBotonMenu(String texto, String tooltip) {
        JButton boton = new JButton(texto);
        boton.setFont(new Font("Segoe UI", Font.BOLD, 13));
        boton.setForeground(Color.WHITE);
        boton.setBackground(COLOR_SIDEBAR_BG);
        boton.setFocusPainted(false);
        boton.setBorderPainted(false);
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        boton.setToolTipText(tooltip);
        boton.setHorizontalAlignment(SwingConstants.LEFT);
        boton.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        boton.setPreferredSize(new Dimension(250, 40));
        boton.setAlignmentX(Component.LEFT_ALIGNMENT);
        boton.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));

        // Efecto interactivo al pasar el ratón (Hover)
        boton.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent evt) {
                boton.setBackground(COLOR_SIDEBAR_HOVER);
            }

            public void mouseExited(MouseEvent evt) {
                boton.setBackground(COLOR_SIDEBAR_BG);
            }
        });
        return boton;
    }

    /**
     * Configura los ActionListeners de la interfaz.
     * Siguiendo el patrón MVC, la Vista solo captura el evento de usuario y delega
     * la lógica y manipulación de datos al Controlador (GestionadorSoporte).
     */
    private void configurarEventosBotones() {
        // Separación MVC: la Vista captura el clic y el Controlador ejecuta la lógica sobre el Min-Heap/Grafo/AVL
        btnCrearTicket.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent eventoClic) {
                String resultado = gestionadorLogica.crearTicketGUI();
                mostrarResultadoOperativo("Registro de Incidencia", "Creación de Ticket", resultado);
            }
        });

        btnAsignarTecnico.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent eventoClic) {
                mostrarPanelAsignacionTecnico();
            }
        });

        btnActualizarEstado.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent eventoClic) {
                String resultado = gestionadorLogica.actualizarEstadoGUI();
                mostrarResultadoOperativo("Control de Incidencia", "Actualización de Estado", resultado);
            }
        });

        btnVerTodosTickets.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent eventoClic) {
                String resultado = gestionadorLogica.mostrarTodosLosTicketsGUI();
                mostrarResultadoOperativo("Historial General", "Listado Completo de Incidencias", resultado);
            }
        });

        btnReporteSLA.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent eventoClic) {
                String resultado = gestionadorLogica.generarReporteSLAGUI();
                mostrarResultadoOperativo("Métricas de Servicio", "Indicadores de Cumplimiento SLA", resultado);
            }
        });

        btnVerGrafo.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent eventoClic) {
                mostrarPanelMapaInfraestructura();
            }
        });

        btnVerArbol.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent eventoClic) {
                mostrarPanelCatalogoCategorias();
            }
        });

        btnSalir.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent eventoClic) {
                int confirm = JOptionPane.showConfirmDialog(null,
                        "¿Está seguro que desea salir del Sistema de Soporte Técnico?", "Confirmar Salida",
                        JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    System.exit(0);
                }
            }
        });
    }

    /**
     * Muestra el panel de control operativo inicial con indicadores y acceso al flujo de trabajo.
     */
    private void mostrarPantallaBienvenida() {
        String html = "<html><head><style>"
                + "body { font-family: 'Segoe UI', Arial, sans-serif; margin: 20px; background-color: #f8fafc; color: #1e293b; }"
                + ".banner { background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%); color: white; padding: 24px; border-radius: 10px; margin-bottom: 20px; }"
                + ".title { font-size: 22px; font-weight: bold; margin-bottom: 6px; color: #f8fafc; }"
                + ".subtitle { font-size: 13px; color: #94a3b8; line-height: 1.5; }"
                + ".status-box { background-color: #f0fdf4; border: 1px solid #bbf7d0; color: #166534; padding: 12px 16px; border-radius: 8px; font-weight: bold; margin-bottom: 20px; font-size: 13px; }"
                + ".panel-title { font-size: 15px; font-weight: bold; color: #0f172a; margin-bottom: 8px; }"
                + ".card { background: white; padding: 18px; border-radius: 8px; border: 1px solid #e2e8f0; }"
                + ".badge-active { background-color: #dcfce7; color: #166534; padding: 3px 8px; border-radius: 4px; font-size: 11px; font-weight: bold; }"
                + ".card-header { font-size: 15px; font-weight: bold; color: #0f172a; margin-bottom: 8px; }"
                + ".card-desc { font-size: 13px; color: #475569; line-height: 1.5; }"
                + ".guide-box { background: white; border: 1px solid #e2e8f0; border-radius: 8px; padding: 18px; margin-top: 15px; }"
                + ".guide-item { font-size: 13px; color: #334155; margin-bottom: 8px; line-height: 1.4; }"
                + "</style></head><body>"
                + "<div class='banner'>"
                + "<div class='title'>Panel de Control Operativo — Mesa de Ayuda</div>"
                + "<div class='subtitle'>Sistema centralizado para la administración y seguimiento de incidencias, monitoreo de infraestructura y catálogos de atención.</div>"
                + "</div>"
                + "<div class='status-box'>✔ Sistema operativo e inicializado. Seleccione una acción en el panel lateral para gestionar incidencias o generar reportes.</div>"
                + "<table style='width:100%; border-collapse: separate; border-spacing: 12px 0;'>"
                + "<tr>"
                + "<td style='width:33%; vertical-align: top;' class='card'>"
                + "<div class='card-header'>Gestión de Incidencias <span class='badge-active'>ACTIVO</span></div>"
                + "<div class='card-desc'>Registro, priorización y asignación de tickets de soporte técnico con monitoreo continuo de estados de atención.</div>"
                + "</td>"
                + "<td style='width:33%; vertical-align: top;' class='card'>"
                + "<div class='card-header'>Mapa de Infraestructura <span class='badge-active'>OPERATIVO</span></div>"
                + "<div class='card-desc'>Control de dependencias entre servidores, bases de datos y módulos empresariales para evaluar impacto operativo.</div>"
                + "</td>"
                + "<td style='width:33%; vertical-align: top;' class='card'>"
                + "<div class='card-header'>Catálogo de Especialidades <span class='badge-active'>DISPONIBLE</span></div>"
                + "<div class='card-desc'>Clasificación jerárquica de especialidades y categorías técnicas para canalizar reportes y solicitudes de servicio.</div>"
                + "</td>"
                + "</tr>"
                + "</table>"
                + "<div class='guide-box'>"
                + "<div class='panel-title'>Flujo Operativo Rápido</div>"
                + "<div class='guide-item'><b>1. Crear Ticket:</b> Registre nuevas incidencias especificando descripción y nivel de urgencia.</div>"
                + "<div class='guide-item'><b>2. Asignar Técnico:</b> Atienda las solicitudes pendientes priorizando los casos críticos automáticamente.</div>"
                + "<div class='guide-item'><b>3. Actualizar Estado:</b> Registre avances y cierres de incidencias para mantener la trazabilidad operativa.</div>"
                + "</div>"
                + "</body></html>";

        areaPantallaResultados.setText(html);
        areaPantallaResultados.setCaretPosition(0);
        cardLayoutCentral.show(panelCentralContainer, "HTML_VIEW");
    }

    private void mostrarResultadoDidactico(String titulo, String subtitulo, String icono, String rawText, String tipo) {
        mostrarResultadoOperativo(titulo, subtitulo, rawText);
    }

    /**
     * Transforma la salida de texto en un panel operativo limpio, minimalista y profesional.
     */
    private void mostrarResultadoOperativo(String titulo, String subtitulo, String rawText) {
        String textoProcesado = rawText != null ? rawText : "";
        textoProcesado = textoProcesado.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");

        // Formateo visual operativo de flechas
        textoProcesado = textoProcesado.replace("-&gt;",
                "<span style='color: #2563eb; font-weight: bold;'> ➔ requiere de ➔ </span>");

        // Distinción visual operativa de prioridades
        textoProcesado = textoProcesado.replace("Prioridad: 1",
                "<span style='background-color: #fee2e2; color: #991b1b; padding: 2px 6px; border-radius: 4px; font-weight: bold;'>Prioridad: 1 (CRÍTICA - SLA 2h)</span>");
        textoProcesado = textoProcesado.replace("Prioridad: 2",
                "<span style='background-color: #fef3c7; color: #92400e; padding: 2px 6px; border-radius: 4px; font-weight: bold;'>Prioridad: 2 (ALTA - SLA 4h)</span>");
        textoProcesado = textoProcesado.replace("Prioridad: 3",
                "<span style='color: #059669; font-weight: bold;'>Prioridad: 3 (MEDIA)</span>");
        textoProcesado = textoProcesado.replace("Prioridad: 4",
                "<span style='color: #2563eb; font-weight: bold;'>Prioridad: 4 (BAJA)</span>");

        // Distinción visual operativa de estados
        textoProcesado = textoProcesado.replace("[Resuelto]",
                "<span style='background-color: #dcfce7; color: #166534; padding: 2px 6px; border-radius: 4px; font-weight: bold;'>[RESUELTO]</span>");
        textoProcesado = textoProcesado.replace("Resuelto",
                "<span style='color: #16a34a; font-weight: bold;'>Resuelto</span>");
        textoProcesado = textoProcesado.replace("[En Proceso]",
                "<span style='background-color: #fef08a; color: #854d0e; padding: 2px 6px; border-radius: 4px; font-weight: bold;'>[EN PROCESO]</span>");
        textoProcesado = textoProcesado.replace("En Proceso",
                "<span style='color: #ca8a04; font-weight: bold;'>En Proceso</span>");

        textoProcesado = textoProcesado.replace("(Servicio Independiente)",
                "<span style='color: #64748b; font-style: italic;'>(Servicio Independiente)</span>");
        textoProcesado = textoProcesado.replace("¡Éxito!",
                "<span style='color: #16a34a; font-weight: bold;'>✔ OPERACIÓN EXITOSA:</span>");
        textoProcesado = textoProcesado.replace("Error:",
                "<span style='color: #dc2626; font-weight: bold;'>✖ ERROR:</span>");

        textoProcesado = textoProcesado.replace("\n", "<br>").replace("  ", "&nbsp;&nbsp;");

        String html = "<html><head><style>"
                + "body { font-family: 'Segoe UI', Arial, sans-serif; margin: 15px; background-color: #f8fafc; color: #1e293b; }"
                + ".card { background-color: #ffffff; border-radius: 8px; padding: 22px; border: 1px solid #cbd5e1; }"
                + ".header { border-bottom: 1px solid #e2e8f0; padding-bottom: 12px; margin-bottom: 16px; }"
                + ".title { font-size: 18px; font-weight: bold; color: #0f172a; }"
                + ".subtitle { font-size: 13px; color: #64748b; margin-top: 3px; }"
                + ".content-box { background-color: #0f172a; color: #f8fafc; padding: 18px; border-radius: 8px; font-family: 'Consolas', 'Courier New', monospace; font-size: 13px; line-height: 1.6; border: 1px solid #334155; }"
                + "</style></head><body>"
                + "<div class='card'>"
                + "<div class='header'>"
                + "<div class='title'>" + titulo + "</div>"
                + "<div class='subtitle'>" + subtitulo + "</div>"
                + "</div>"
                + "<div class='content-box'>" + textoProcesado + "</div>"
                + "</div>"
                + "</body></html>";

        areaPantallaResultados.setText(html);
        areaPantallaResultados.setCaretPosition(0);
        cardLayoutCentral.show(panelCentralContainer, "HTML_VIEW");
    }

    /**
     * Muestra el panel operativo para seleccionar un técnico del JComboBox antes de
     * desencolar el ticket de máxima prioridad.
     */
    private void mostrarPanelAsignacionTecnico() {
        panelAsignacionTecnico.removeAll();
        panelAsignacionTecnico.setLayout(new BorderLayout());
        panelAsignacionTecnico.setBorder(BorderFactory.createEmptyBorder(25, 30, 25, 30));

        JPanel tarjeta = new JPanel();
        tarjeta.setLayout(new BoxLayout(tarjeta, BoxLayout.Y_AXIS));
        tarjeta.setBackground(Color.WHITE);
        tarjeta.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(203, 213, 225), 1),
                BorderFactory.createEmptyBorder(25, 25, 25, 25)
        ));

        JLabel lblTitulo = new JLabel("Asignar Técnico a Incidencia Prioritaria");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblTitulo.setForeground(new Color(15, 23, 42));
        lblTitulo.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel lblSubtitulo = new JLabel("El sistema extraerá y desencolará automáticamente el ticket de máxima prioridad en la cola.");
        lblSubtitulo.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lblSubtitulo.setForeground(new Color(100, 116, 139));
        lblSubtitulo.setAlignmentX(Component.LEFT_ALIGNMENT);

        tarjeta.add(lblTitulo);
        tarjeta.add(Box.createRigidArea(new Dimension(0, 6)));
        tarjeta.add(lblSubtitulo);
        tarjeta.add(Box.createRigidArea(new Dimension(0, 22)));

        boolean hayTickets = gestionadorLogica.hayTicketsPendientes();

        JLabel lblSeleccion = new JLabel("Seleccione Técnico Especialista:");
        lblSeleccion.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblSeleccion.setForeground(new Color(51, 65, 85));
        lblSeleccion.setAlignmentX(Component.LEFT_ALIGNMENT);

        JComboBox<String> comboTecnicos = new JComboBox<>(gestionadorLogica.getTecnicosDisponibles());
        comboTecnicos.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        comboTecnicos.setMaximumSize(new Dimension(420, 36));
        comboTecnicos.setPreferredSize(new Dimension(360, 36));
        comboTecnicos.setAlignmentX(Component.LEFT_ALIGNMENT);
        comboTecnicos.setEnabled(hayTickets);

        JButton btnAsignarPrioritario = new JButton("Asignar Ticket Prioritario");
        btnAsignarPrioritario.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnAsignarPrioritario.setBackground(COLOR_ACCENT_BLUE);
        btnAsignarPrioritario.setForeground(Color.WHITE);
        btnAsignarPrioritario.setFocusPainted(false);
        btnAsignarPrioritario.setCursor(hayTickets ? new Cursor(Cursor.HAND_CURSOR) : new Cursor(Cursor.DEFAULT_CURSOR));
        btnAsignarPrioritario.setAlignmentX(Component.LEFT_ALIGNMENT);
        btnAsignarPrioritario.setEnabled(hayTickets);

        tarjeta.add(lblSeleccion);
        tarjeta.add(Box.createRigidArea(new Dimension(0, 8)));
        tarjeta.add(comboTecnicos);
        tarjeta.add(Box.createRigidArea(new Dimension(0, 18)));
        tarjeta.add(btnAsignarPrioritario);

        if (!hayTickets) {
            tarjeta.add(Box.createRigidArea(new Dimension(0, 20)));
            JLabel lblVacio = new JLabel("No hay tickets pendientes de atención en este momento");
            lblVacio.setFont(new Font("Segoe UI", Font.BOLD, 13));
            lblVacio.setForeground(new Color(185, 28, 28));
            lblVacio.setAlignmentX(Component.LEFT_ALIGNMENT);
            tarjeta.add(lblVacio);
        }

        btnAsignarPrioritario.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String tecnicoSeleccionado = (String) comboTecnicos.getSelectedItem();
                String resultado = gestionadorLogica.asignarTecnicoGUI(tecnicoSeleccionado);
                mostrarResultadoOperativo("Atención de Incidencia", "Asignación de Técnico", resultado);
            }
        });

        JPanel wrapperTop = new JPanel(new BorderLayout());
        wrapperTop.setBackground(COLOR_BG_LIGHT);
        wrapperTop.add(tarjeta, BorderLayout.NORTH);

        panelAsignacionTecnico.add(wrapperTop, BorderLayout.CENTER);
        panelAsignacionTecnico.revalidate();
        panelAsignacionTecnico.repaint();

        cardLayoutCentral.show(panelCentralContainer, "ASIGNACION_VIEW");
    }

    /**
     * Muestra el panel interactivo del Mapa de Infraestructura usando datos de GrafoSistemas
     * con un JTable profesional y JTextArea no editable con scroll.
     */
    private void mostrarPanelMapaInfraestructura() {
        panelMapaInfraestructura.removeAll();
        panelMapaInfraestructura.setLayout(new BorderLayout());
        panelMapaInfraestructura.setBorder(BorderFactory.createEmptyBorder(20, 25, 20, 25));

        JPanel headerPanel = new JPanel();
        headerPanel.setLayout(new BoxLayout(headerPanel, BoxLayout.Y_AXIS));
        headerPanel.setBackground(Color.WHITE);
        headerPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(203, 213, 225), 1),
                BorderFactory.createEmptyBorder(15, 20, 15, 20)
        ));

        JLabel lblTitulo = new JLabel("Mapa de Infraestructura — Topología de Red (Grafo Dirigido)");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblTitulo.setForeground(new Color(15, 23, 42));

        JLabel lblSubtitulo = new JLabel("Relaciones de dependencia operativa e impacto en cascada entre servicios corporativos.");
        lblSubtitulo.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lblSubtitulo.setForeground(new Color(100, 116, 139));

        headerPanel.add(lblTitulo);
        headerPanel.add(Box.createRigidArea(new Dimension(0, 4)));
        headerPanel.add(lblSubtitulo);

        String[] columnas = {"Sistema / Servicio Corporativo", "Requiere para operar (Depende de)", "Impacto si falla (Afecta a)"};
        Object[][] datos = gestionadorLogica.obtenerDatosTablaGrafo();

        JTable tablaGrafo = new JTable(datos, columnas) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tablaGrafo.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tablaGrafo.setRowHeight(28);
        tablaGrafo.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        tablaGrafo.getTableHeader().setBackground(new Color(241, 245, 249));
        tablaGrafo.getTableHeader().setForeground(new Color(30, 41, 59));

        JScrollPane scrollTabla = new JScrollPane(tablaGrafo);
        scrollTabla.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(203, 213, 225)),
                "Matriz de Adyacencia Estructurada",
                0, 0, new Font("Segoe UI", Font.BOLD, 12), new Color(51, 65, 85)
        ));

        JTextArea areaAdyacencia = new JTextArea();
        areaAdyacencia.setEditable(false);
        areaAdyacencia.setFont(new Font("Consolas", Font.PLAIN, 13));
        areaAdyacencia.setBackground(new Color(15, 23, 42));
        areaAdyacencia.setForeground(new Color(248, 250, 252));
        areaAdyacencia.setMargin(new Insets(12, 12, 12, 12));

        StringBuilder adyText = new StringBuilder();
        adyText.append("--- LISTA DE ADYACENCIA E IMPACTO DE INFRAESTRUCTURA ---\n\n");
        for (Object[] fila : datos) {
            adyText.append("[").append(fila[0]).append("]\n");
            adyText.append("  ➔ Requiere de : ").append(fila[1]).append("\n");
            adyText.append("  ➔ Afecta a    : ").append(fila[2]).append("\n");
            adyText.append("--------------------------------------------------\n");
        }
        areaAdyacencia.setText(adyText.toString());
        areaAdyacencia.setCaretPosition(0);

        JScrollPane scrollTexto = new JScrollPane(areaAdyacencia);
        scrollTexto.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(203, 213, 225)),
                "Lista de Adyacencia (Vista de Consola)",
                0, 0, new Font("Segoe UI", Font.BOLD, 12), new Color(51, 65, 85)
        ));

        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, scrollTabla, scrollTexto);
        splitPane.setResizeWeight(0.55);
        splitPane.setDividerSize(6);
        splitPane.setBorder(null);

        JPanel contentWrapper = new JPanel(new BorderLayout(0, 15));
        contentWrapper.setBackground(COLOR_BG_LIGHT);
        contentWrapper.add(headerPanel, BorderLayout.NORTH);
        contentWrapper.add(splitPane, BorderLayout.CENTER);

        panelMapaInfraestructura.add(contentWrapper, BorderLayout.CENTER);
        panelMapaInfraestructura.revalidate();
        panelMapaInfraestructura.repaint();

        cardLayoutCentral.show(panelCentralContainer, "GRAFO_VIEW");
    }

    /**
     * Muestra el panel interactivo del Catálogo de Categorías usando un JTree
     * para representar visualmente el Árbol AVL jerárquico.
     */
    private void mostrarPanelCatalogoCategorias() {
        panelCatalogoCategorias.removeAll();
        panelCatalogoCategorias.setLayout(new BorderLayout());
        panelCatalogoCategorias.setBorder(BorderFactory.createEmptyBorder(20, 25, 20, 25));

        JPanel headerPanel = new JPanel();
        headerPanel.setLayout(new BoxLayout(headerPanel, BoxLayout.Y_AXIS));
        headerPanel.setBackground(Color.WHITE);
        headerPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(203, 213, 225), 1),
                BorderFactory.createEmptyBorder(15, 20, 15, 20)
        ));

        JLabel lblTitulo = new JLabel("Catálogo Jerárquico de Categorías (Árbol AVL)");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblTitulo.setForeground(new Color(15, 23, 42));

        JLabel lblSubtitulo = new JLabel("Jerarquía auto-balanceada de especialidades. Haga clic en las carpetas para expandir o contraer subcategorías.");
        lblSubtitulo.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lblSubtitulo.setForeground(new Color(100, 116, 139));

        headerPanel.add(lblTitulo);
        headerPanel.add(Box.createRigidArea(new Dimension(0, 4)));
        headerPanel.add(lblSubtitulo);

        DefaultMutableTreeNode raizModelo = gestionadorLogica.obtenerModeloArbolJTree();
        JTree arbolJTree = new JTree(raizModelo);
        arbolJTree.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        arbolJTree.setRowHeight(30);
        arbolJTree.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        // Expandir todos los nodos por defecto para visualizar la jerarquía
        for (int i = 0; i < arbolJTree.getRowCount(); i++) {
            arbolJTree.expandRow(i);
        }

        JScrollPane scrollArbol = new JScrollPane(arbolJTree);
        scrollArbol.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(203, 213, 225)),
                BorderFactory.createEmptyBorder(5, 5, 5, 5)
        ));
        scrollArbol.getViewport().setBackground(Color.WHITE);

        JPanel contentWrapper = new JPanel(new BorderLayout(0, 15));
        contentWrapper.setBackground(COLOR_BG_LIGHT);
        contentWrapper.add(headerPanel, BorderLayout.NORTH);
        contentWrapper.add(scrollArbol, BorderLayout.CENTER);

        panelCatalogoCategorias.add(contentWrapper, BorderLayout.CENTER);
        panelCatalogoCategorias.revalidate();
        panelCatalogoCategorias.repaint();

        cardLayoutCentral.show(panelCentralContainer, "ARBOL_VIEW");
    }

    // Método principal (Entry Point) que arranca la aplicación gráfica
    public static void main(String[] args) {
        // Configurar Look and Feel moderno de forma segura
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception e) {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ex) {
                // Si falla, se usa el look and feel por defecto de Java
            }
        }

        // Ejecución segura en el Event Dispatch Thread (EDT)
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new SistemaSoporteEDFISIGrupo3().setVisible(true);
            }
        });
    }
}
