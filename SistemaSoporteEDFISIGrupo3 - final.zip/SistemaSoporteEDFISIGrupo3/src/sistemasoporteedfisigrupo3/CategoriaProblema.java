package sistemasoporteedfisigrupo3;

// ============================================================================
// ESTRUCTURA DE DATOS: NODO VALOR DEL ÁRBOL AVL (Categoría del Catálogo)
// ============================================================================

/**
 * Modelo de dominio que representa una especialidad o categoría dentro del catálogo de incidencias del Help Desk.
 * <p><b>Cumplimiento OOP y Rúbrica:</b></p>
 * <ul>
 *   <li><b>Encapsulación:</b> Atributos privados con métodos accesores inmutables tras su construcción.</li>
 *   <li><b>Comparable:</b> Implementa la interfaz {@link Comparable} para dictar el orden algorítmico por código dentro del Árbol AVL.</li>
 *   <li><b>Manejo de Excepciones:</b> Valida que el código sea un entero positivo y que el nombre de la categoría no esté vacío.</li>
 * </ul>
 */
class CategoriaProblema implements Comparable<CategoriaProblema> {
    
    // Atributos privados (Encapsulación estricta)
    private int codigoCategoria;
    private String nombreCategoria;

    /**
     * Constructor para definir una categoría en el árbol de soporte.
     * 
     * @param codigo Identificador numérico jerárquico único (ej. 10, 15, 30).
     * @param nombre Nombre descriptivo de la especialidad (ej. "Hardware Servidores").
     * @throws IllegalArgumentException si el código es negativo o el nombre es nulo/vacío.
     */
    public CategoriaProblema(int codigo, String nombre) {
        //dv
        //inicio
        if (codigo <= 0) {
            throw new IllegalArgumentException("El código de la categoría debe ser un número positivo mayor a 0.");
        }
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre de la categoría no puede estar vacío ni ser nulo.");
        }

        this.codigoCategoria = codigo;
        this.nombreCategoria = nombre.trim();
        //fin
    }

    public int getCodigoCategoria() { 
        return codigoCategoria; 
    }
    
    public String getNombreCategoria() { 
        return nombreCategoria; 
    }

    /**
     * Compara dos categorías por su código numérico para la inserción y balanceo en el Árbol AVL.
     */
    @Override
    public int compareTo(CategoriaProblema otra) {
        if (otra == null) {
            throw new IllegalArgumentException("No se puede comparar contra una categoría nula.");
        }
        return Integer.compare(this.codigoCategoria, otra.codigoCategoria);
    }

    @Override
    public String toString() {
        return "[" + codigoCategoria + "] " + nombreCategoria;
    }
}