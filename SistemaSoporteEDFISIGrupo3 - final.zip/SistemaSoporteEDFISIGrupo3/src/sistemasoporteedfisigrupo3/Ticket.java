package sistemasoporteedfisigrupo3;

// ============================================================================
// DISEÑO OOP: HERENCIA Y ENCAPSULACIÓN (Clase Base Abstracta + Clase Dominio)
// ============================================================================

import java.time.LocalDateTime;

/**
 * Clase base abstracta que demuestra el uso de <b>Herencia</b> en el diseño orientado a objetos.
 * Define los atributos comunes de cualquier entidad rastreable dentro del sistema corporativo de Data Computer.
 * <p><b>Cumplimiento OOP:</b> Aplica encapsulación mediante modificadores de acceso {@code protected} y métodos accesores.</p>
 */
abstract class EntidadSoporte {
    // Atributos protegidos para permitir el acceso controlado por herencia en subclases
    protected int identificador;
    protected LocalDateTime fechaHoraCreacion;

    /**
     * Constructor base para inicializar la identidad y marca de tiempo de la entidad.
     * @param id Número identificador único positivo.
     * @throws IllegalArgumentException si el id es menor o igual a 0.
     */
    public EntidadSoporte(int id) {
        if (id <= 0) {
            throw new IllegalArgumentException("El identificador de la entidad debe ser un número positivo mayor a 0.");
        }
        this.identificador = id;
        this.fechaHoraCreacion = LocalDateTime.now();
    }

    public int getIdentificador() {
        return identificador;
    }

    public LocalDateTime getFechaHoraCreacion() {
        return fechaHoraCreacion;
    }

    public void setFechaHoraCreacion(LocalDateTime fecha) {
        this.fechaHoraCreacion = fecha;
    }
}

/**
 * Clase de dominio que representa una incidencia o Ticket en la Mesa de Ayuda de Data Computer.
 * <p><b>Cumplimiento de la Rúbrica:</b></p>
 * <ul>
 *   <li><b>Herencia:</b> Extiende de {@link EntidadSoporte} heredando la gestión de ID y fecha de creación.</li>
 *   <li><b>Polimorfismo e Interfaz:</b> Implementa {@link Comparable} para definir el criterio de ordenamiento natural en el Montículo Binario (Heap).</li>
 *   <li><b>Encapsulación:</b> Atributos privados con validación en setters para proteger la integridad de los datos.</li>
 *   <li><b>Manejo de Excepciones:</b> El constructor valida que la descripción no esté vacía ni sea nula, y que la prioridad sea válida.</li>
 * </ul>
 */
class Ticket extends EntidadSoporte implements Comparable<Ticket> {
    
    // Atributos privados (Encapsulación estricta)
    private String descripcionProblema;
    private int nivelPrioridad; // 1: Crítico (SLA 2h), 2: Alto (SLA 4h), 3: Medio (SLA 8h), 4: Bajo (SLA 24h)
    private String estadoActual; // "Abierto", "En Proceso", "Resuelto"
    private LocalDateTime fechaHoraResolucion;
    private String nombreTecnicoAsignado;

    /**
     * Constructor para inicializar un nuevo ticket de soporte técnico.
     * 
     * @param id Identificador único correlativo del ticket.
     * @param descripcion Detalle o resumen del fallo reportado por el usuario.
     * @param prioridad Nivel de urgencia numérico (1 = Crítico a 4 = Bajo).
     * @throws IllegalArgumentException si la descripción es inválida o la prioridad está fuera de rango [1-4].
     */
    public Ticket(int id, String descripcion, int prioridad) {
        //dv
        super(id); // Llamada al constructor de la superclase (Herencia)
        
        //inicio
        if (descripcion == null || descripcion.trim().isEmpty()) {
            throw new IllegalArgumentException("La descripción del problema no puede estar vacía ni ser nula.");
        }
        if (prioridad < 1 || prioridad > 4) {
            throw new IllegalArgumentException("El nivel de prioridad debe estar en el rango de 1 (Crítico) a 4 (Bajo).");
        }

        this.descripcionProblema = descripcion.trim();
        this.nivelPrioridad = prioridad;
        this.estadoActual = "Abierto";
        this.fechaHoraResolucion = null;
        this.nombreTecnicoAsignado = "Ninguno";
        //fin
    }

    // Métodos accesores (Getters y Setters con encapsulación)
    public int getIdentificadorTicket() { 
        return getIdentificador(); 
    }
    
    public String getDescripcionProblema() { 
        return descripcionProblema; 
    }
    
    public int getNivelPrioridad() { 
        return nivelPrioridad; 
    }
    
    public void setNivelPrioridad(int prioridad) {
        if (prioridad < 1 || prioridad > 4) {
            throw new IllegalArgumentException("Prioridad inválida. Debe ser entre 1 y 4.");
        }
        this.nivelPrioridad = prioridad;
    }
    
    public String getEstadoActual() { 
        return estadoActual; 
    }
    
    public void setEstadoActual(String estado) { 
        if (estado == null || estado.trim().isEmpty()) {
            throw new IllegalArgumentException("El estado del ticket no puede ser nulo o vacío.");
        }
        this.estadoActual = estado; 
    }
    
    public LocalDateTime getFechaHoraResolucion() { 
        return fechaHoraResolucion; 
    }
    
    public void setFechaHoraResolucion(LocalDateTime fecha) { 
        this.fechaHoraResolucion = fecha; 
    }
    
    public String getNombreTecnicoAsignado() { 
        return nombreTecnicoAsignado; 
    }
    
    public void setNombreTecnicoAsignado(String tecnico) { 
        if (tecnico == null || tecnico.trim().isEmpty()) {
            this.nombreTecnicoAsignado = "No Asignado";
        } else {
            this.nombreTecnicoAsignado = tecnico; 
        }
    }

    /**
     * Compara dos tickets para determinar cuál tiene mayor prioridad en la Cola de Prioridad (Montículo).
     * <p><b>Criterio algorítmico:</b></p>
     * <ol>
     *   <li>Menor número de prioridad numérica = Mayor urgencia (ej. 1 es más urgente que 4).</li>
     *   <li>Ante empate de prioridad, se aplica ordenamiento FIFO según el ID o fecha de creación (el más antiguo va primero).</li>
     * </ol>
     * @param otro Ticket con el cual comparar.
     * @return Valor negativo si este ticket es más prioritario, positivo si es menos prioritario, o 0 si son idénticos.
     */
    @Override
    public int compareTo(Ticket otro) {
        if (otro == null) {
            throw new IllegalArgumentException("No se puede comparar contra un ticket nulo.");
        }
        int comparacionPrioridad = Integer.compare(this.nivelPrioridad, otro.nivelPrioridad);
        if (comparacionPrioridad != 0) {
            return comparacionPrioridad;
        }
        // Si tienen la misma prioridad, el ticket creado primero (menor ID) tiene preferencia
        return Integer.compare(this.getIdentificador(), otro.getIdentificador());
    }

    @Override
    public String toString() {
        return "Ticket #" + getIdentificador() + " [Prioridad: " + nivelPrioridad + "] - " + descripcionProblema + " (" + estadoActual + ")";
    }
}

