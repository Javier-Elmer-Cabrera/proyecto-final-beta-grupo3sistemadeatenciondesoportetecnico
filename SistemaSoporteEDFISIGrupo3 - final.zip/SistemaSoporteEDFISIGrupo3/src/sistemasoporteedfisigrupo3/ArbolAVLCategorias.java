package sistemasoporteedfisigrupo3;

// ============================================================================
// ESTRUCTURA DE DATOS 1: ÁRBOL AVL (Catálogo de Categorías Jerárquicas)
// ============================================================================

/**
 * Implementación en memoria RAM de un <b>Árbol Binario de Búsqueda Auto-Balanceado (AVL)</b>.
 * <p>Organiza jerárquicamente las categorías y subcategorías de problemas técnicos (ej. Hardware, Redes, Software).
 * Garantiza algorítmicamente que la diferencia de alturas entre los subárboles izquierdo y derecho de cualquier nodo
 * (conocido como <b>Factor de Equilibrio</b>) sea siempre -1, 0 o +1.</p>
 * <p><b>Complejidad Algorítmica:</b></p>
 * <ul>
 *   <li>Búsqueda: <b>O(log n)</b> en el peor de los casos gracias al auto-balanceo constante.</li>
 *   <li>Inserción: <b>O(log n)</b> incluyendo el tiempo constante O(1) de las rotaciones simples o dobles.</li>
 * </ul>
 */
class ArbolAVLCategorias {
    // Atributo privado que referencia a la raíz de la estructura jerárquica (Encapsulación)
    private NodoArbolAVL raizArbol;

    /**
     * Obtiene la altura de un nodo de forma segura controlando referencias nulas.
     * @param nodoActual Nodo cuya altura se desea consultar.
     * @return 0 si el nodo es nulo (subárbol vacío), o el entero de su altura nodo.
     */
    private int obtenerAltura(NodoArbolAVL nodoActual) {
        //dv
        int alturaCalculada;
        
        //inicio
        if (nodoActual == null) {
            alturaCalculada = 0;
        } else {
            alturaCalculada = nodoActual.alturaNodo;
        }
        return alturaCalculada;
        //fin
    }

    /**
     * Calcula el <b>Factor de Equilibrio</b> de un nodo para determinar si existe desbalance en sus ramas.
     * <p>Fórmula: {@code Altura(SubárbolIzquierdo) - Altura(SubárbolDerecho)}.</p>
     * @param nodoActual Nodo a auditar.
     * @return Valor numérico. Si es &gt; 1 o &lt; -1, el árbol requiere una rotación de reestructuración.
     */
    private int obtenerFactorEquilibrio(NodoArbolAVL nodoActual) {
        //dv
        int factorCalculado;
        
        //inicio
        if (nodoActual == null) {
            factorCalculado = 0;
        } else {
            factorCalculado = obtenerAltura(nodoActual.nodoIzquierdo) - obtenerAltura(nodoActual.nodoDerecho);
        }
        return factorCalculado;
        //fin
    }

    /**
     * Ejecuta una <b>Rotación Simple a la Derecha (LL - Left-Left Case)</b> para reequilibrar una rama cargada a la izquierda.
     * @param nodoY Nodo desbalanceado con factor de equilibrio &gt; 1.
     * @return Nueva raíz del subárbol rotado.
     */
    private NodoArbolAVL rotarDerecha(NodoArbolAVL nodoY) {
        //dv
        NodoArbolAVL nodoX;
        NodoArbolAVL subArbolT2;

        //inicio
        nodoX = nodoY.nodoIzquierdo;
        subArbolT2 = nodoX.nodoDerecho;

        // Rotación
        nodoX.nodoDerecho = nodoY;
        nodoY.nodoIzquierdo = subArbolT2;

        // Actualización de alturas desde las hojas hacia la raíz local
        nodoY.alturaNodo = Math.max(obtenerAltura(nodoY.nodoIzquierdo), obtenerAltura(nodoY.nodoDerecho)) + 1;
        nodoX.alturaNodo = Math.max(obtenerAltura(nodoX.nodoIzquierdo), Math.max(obtenerAltura(nodoX.nodoDerecho), 0)) + 1;

        return nodoX;
        //fin
    }

    /**
     * Ejecuta una <b>Rotación Simple a la Izquierda (RR - Right-Right Case)</b> para reequilibrar una rama cargada a la derecha.
     * @param nodoX Nodo desbalanceado con factor de equilibrio &lt; -1.
     * @return Nueva raíz del subárbol rotado.
     */
    private NodoArbolAVL rotarIzquierda(NodoArbolAVL nodoX) {
        //dv
        NodoArbolAVL nodoY;
        NodoArbolAVL subArbolT2;

        //inicio
        nodoY = nodoX.nodoDerecho;
        subArbolT2 = nodoY.nodoIzquierdo;

        // Rotación
        nodoY.nodoIzquierdo = nodoX;
        nodoX.nodoDerecho = subArbolT2;

        // Actualización de alturas
        nodoX.alturaNodo = Math.max(obtenerAltura(nodoX.nodoIzquierdo), obtenerAltura(nodoX.nodoDerecho)) + 1;
        nodoY.alturaNodo = Math.max(obtenerAltura(nodoY.nodoIzquierdo), Math.max(obtenerAltura(nodoY.nodoDerecho), 0)) + 1;

        return nodoY;
        //fin
    }

    /**
     * Inserta una nueva categoría en el catálogo jerárquico auto-balanceado.
     * @param nuevaCategoria Objeto {@link CategoriaProblema} a registrar.
     * @throws IllegalArgumentException si la categoría ingresada es nula.
     */
    public void insertar(CategoriaProblema nuevaCategoria) {
        //dv
        //inicio
        if (nuevaCategoria == null) {
            throw new IllegalArgumentException("No se puede insertar una categoría nula en el árbol AVL.");
        }
        raizArbol = insertarRecursivo(raizArbol, nuevaCategoria);
        //fin
    }

    /**
     * Lógica recursiva interna para la inserción en árbol binario de búsqueda y posterior evaluación de los 4 casos de balanceo AVL.
     */
    private NodoArbolAVL insertarRecursivo(NodoArbolAVL nodoActual, CategoriaProblema nuevaCategoria) {
        //dv
        int balance;

        //inicio
        if (nodoActual == null) {
            return new NodoArbolAVL(nuevaCategoria);
        }

        // 1. Recorrido tipo ABB: menor al subárbol izquierdo, mayor al subárbol derecho en O(log n)
        int comparacion = nuevaCategoria.compareTo(nodoActual.datoCategoria);
        if (comparacion < 0) {
            nodoActual.nodoIzquierdo = insertarRecursivo(nodoActual.nodoIzquierdo, nuevaCategoria);
        } else if (comparacion > 0) {
            nodoActual.nodoDerecho = insertarRecursivo(nodoActual.nodoDerecho, nuevaCategoria);
        } else {
            return nodoActual; // Evitamos duplicados en el catálogo corporativo
        }

        // 2. Actualizamos la altura del ancestro en la fase de retroceso recursivo (Backtracking)
        nodoActual.alturaNodo = 1 + Math.max(obtenerAltura(nodoActual.nodoIzquierdo), obtenerAltura(nodoActual.nodoDerecho));
        
        // 3. Calculamos el factor de equilibrio (FE = Altura Izq - Altura Der). Si |FE| > 1 reestructuramos en O(1)
        balance = obtenerFactorEquilibrio(nodoActual);

        // Caso Izquierda-Izquierda (LL): desbalance por inserción en rama izquierda del hijo izquierdo
        if (balance > 1 && nuevaCategoria.getCodigoCategoria() < nodoActual.nodoIzquierdo.datoCategoria.getCodigoCategoria()) {
            return rotarDerecha(nodoActual);
        }
        // Caso Derecha-Derecha (RR): desbalance por inserción en rama derecha del hijo derecho
        if (balance < -1 && nuevaCategoria.getCodigoCategoria() > nodoActual.nodoDerecho.datoCategoria.getCodigoCategoria()) {
            return rotarIzquierda(nodoActual);
        }
        // Caso Izquierda-Derecha (LR - Rotación Doble): primero rotación izquierda al hijo, luego derecha al nodo
        if (balance > 1 && nuevaCategoria.getCodigoCategoria() > nodoActual.nodoIzquierdo.datoCategoria.getCodigoCategoria()) {
            nodoActual.nodoIzquierdo = rotarIzquierda(nodoActual.nodoIzquierdo);
            return rotarDerecha(nodoActual);
        }
        // Caso Derecha-Izquierda (RL - Rotación Doble): primero rotación derecha al hijo, luego izquierda al nodo
        if (balance < -1 && nuevaCategoria.getCodigoCategoria() < nodoActual.nodoDerecho.datoCategoria.getCodigoCategoria()) {
            nodoActual.nodoDerecho = rotarDerecha(nodoActual.nodoDerecho);
            return rotarIzquierda(nodoActual);
        }

        return nodoActual;
        //fin
    }

    /**
     * Genera una representación textual jerárquica del árbol (rotado 90 grados) para ser renderizada en la interfaz gráfica.
     * @return Cadena formateada con indentaciones que demuestran la estructura del árbol en memoria.
     */
    public String obtenerArbolTextoGUI() {
        //dv
        StringBuilder constructorTexto;
        
        //inicio
        constructorTexto = new StringBuilder();
        constructorTexto.append("--- CATÁLOGO DE CATEGORÍAS TÉCNICAS ---\n\n");
        if (raizArbol == null) {
            constructorTexto.append("El catálogo de categorías se encuentra actualmente vacío.\n");
        } else {
            construirInOrderRecursivo(raizArbol, 0, constructorTexto);
        }
        return constructorTexto.toString();
        //fin
    }

    /**
     * Recorrido recursivo In-Order inverso (Derecha -> Raíz -> Izquierda) para visualización en árbol horizontal.
     */
    private void construirInOrderRecursivo(NodoArbolAVL nodoActual, int espacio, StringBuilder constructor) {
        //dv
        //inicio
        if (nodoActual != null) {
            espacio += 5;
            construirInOrderRecursivo(nodoActual.nodoDerecho, espacio, constructor);
            constructor.append("\n");
            for (int i = 5; i < espacio; i++) {
                constructor.append(" ");
            }
            constructor.append("[").append(nodoActual.datoCategoria.getCodigoCategoria()).append("] ").append(nodoActual.datoCategoria.getNombreCategoria());
            construirInOrderRecursivo(nodoActual.nodoIzquierdo, espacio, constructor);
        }
        //fin
    }

    public NodoArbolAVL getRaizArbol() {
        return raizArbol;
    }
}

