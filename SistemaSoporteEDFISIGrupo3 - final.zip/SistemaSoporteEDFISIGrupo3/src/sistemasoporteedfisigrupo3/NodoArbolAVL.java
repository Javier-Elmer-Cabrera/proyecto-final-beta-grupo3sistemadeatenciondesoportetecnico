package sistemasoporteedfisigrupo3;

// ============================================================================
// ESTRUCTURA DE DATOS 1: ÁRBOL AVL - NODO BINARIO AUTO-BALANCEADO
// ============================================================================

/**
 * Clase que representa un nodo individual dentro del Árbol Binario de Búsqueda Auto-Balanceado (AVL).
 * <p>Cada nodo almacena una categoría técnica del catálogo corporativo y mantiene registro de la altura de su subárbol,
 * lo que permite calcular el <b>Factor de Equilibrio</b> en tiempo de inserción para decidir rotaciones.</p>
 */
class NodoArbolAVL {
    // Atributos con visibilidad de paquete para optimización en operaciones recursivas de ArbolAVLCategorias
    CategoriaProblema datoCategoria;
    NodoArbolAVL nodoIzquierdo;
    NodoArbolAVL nodoDerecho;
    int alturaNodo;

    /**
     * Constructor para inicializar un nodo hoja del árbol AVL.
     * @param categoria Objeto de tipo {@link CategoriaProblema} que se almacenará en este nodo.
     * @throws IllegalArgumentException si la categoría a almacenar es nula.
     */
    public NodoArbolAVL(CategoriaProblema categoria) {
        //dv
        //inicio
        if (categoria == null) {
            throw new IllegalArgumentException("El nodo del árbol AVL no puede ser inicializado con una categoría nula.");
        }
        this.datoCategoria = categoria;
        this.alturaNodo = 1; // Por definición algorítmica, una hoja nueva siempre nace con altura 1
        //fin
    }
}